package com.example.rammanager.model

const val DESIGN_CAPACITY_MAH = 4500

/**
 * Type of battery state session recorded
 */
enum class BatterySessionType(val displayName: String) {
    CHARGING("Pengisian Daya"),
    DISCHARGING("Pemakaian Baterai")
}

/**
 * Real-time electrical measurements from BatteryManager & kernel sysfs
 */
data class BatteryCurrentFlow(
    val currentNowMa: Int,           // Positive = charging, Negative = discharging
    val currentAverageMa: Int,       // Moving average
    val voltageMv: Int,              // e.g. 4085 mV
    val powerWatts: Double,          // V * I / 1000
    val temperatureC: Double,        // Battery thermistor
    val isCharging: Boolean,
    val chargeSpeedType: String,     // Fast Charging, Normal, USB, etc.
    val currentAvailable: Boolean = true
) {
    val formattedCurrent: String
        get() = if (currentNowMa >= 0) "+${currentNowMa} mA" else "${currentNowMa} mA"

    val formattedPower: String
        get() = String.format("%.2f W", kotlin.math.abs(powerWatts))
}

/**
 * Stored historical session (AccuBattery style) to improve future estimation accuracy
 */
data class BatterySessionRecord(
    val id: String,
    val sessionType: BatterySessionType,
    val startTime: Long,
    val endTime: Long,
    val durationMinutes: Int,
    val startLevelPercent: Int,
    val endLevelPercent: Int,
    val energyMah: Double,           // Total mAh charged or consumed
    val avgCurrentMa: Int,
    val peakTemperatureC: Double,
    val chargerType: String? = null
) {
    val levelDelta: Int
        get() = kotlin.math.abs(endLevelPercent - startLevelPercent)

    val formattedEnergy: String
        get() = String.format("%.0f mAh", energyMah)
}

/**
 * Battery Health analysis calculated from real historical charge sessions
 */
data class BatteryHealthReport(
    val designCapacityMah: Int,       // e.g., 4500 mAh for S21 FE
    val estimatedCapacityMah: Double, // Estimated from cumulative charge sessions
    val healthPercent: Double,        // (estimated / design) * 100
    val cycleCount: Int,
    val wearLevelPercent: Double,     // 100 - healthPercent
    val condition: String,            // "Sangat Baik", "Baik", "Perlu Perhatian", "Servis"
    val totalSessionsLearned: Int,
    val accuracyScorePercent: Int     // Higher count = higher accuracy confidence (up to 98%)
) {
    val formattedHealth: String
        get() = String.format("%.1f%%", healthPercent)

    val formattedEstimatedCapacity: String
        get() = String.format("%.0f mAh", estimatedCapacityMah)
}

/**
 * Estimated time remaining for popular daily activities
 */
data class ActivityDrainEstimate(
    val id: String,
    val activityName: String,
    val category: String,
    val drainRatePercentPerHour: Double,
    val minutesRemaining: Int
) {
    val formattedRemaining: String
        get() {
            val hours = minutesRemaining / 60
            val mins = minutesRemaining % 60
            return if (hours > 0) "${hours}j ${mins}m" else "${mins}m"
        }
}

/**
 * Smart estimates calculated based on current battery level & historical drain rates
 */
data class BatterySmartEstimates(
    val timeToFullMinutes: Int?,
    val timeTo80PercentMinutes: Int?,
    val timeToEmptyScreenOnMinutes: Int,
    val timeToEmptyScreenOffMinutes: Int,
    val timeToEmptyMixedMinutes: Int,
    val activities: List<ActivityDrainEstimate> = emptyList()
) {
    fun formatMinutes(mins: Int?): String {
        if (mins == null || mins <= 0) return "--"
        val hours = mins / 60
        val remainder = mins % 60
        return if (hours > 0) "${hours} jam ${remainder} mnt" else "${remainder} menit"
    }
}
