package com.example.rammanager

import android.os.Build
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rammanager.data.HistoryRepository
import com.example.rammanager.model.*
import com.example.rammanager.shizuku.ShizukuCommandRunner
import kotlinx.coroutines.launch
import kotlin.math.abs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RamScreen(
    isShizukuActive: Boolean,
    hasShizukuPermission: Boolean,
    onRequestPermission: () -> Unit,
    ramOverview: RamOverview?,
    processes: List<AppProcessInfo>,
    isLoading: Boolean,
    onRefresh: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val historyRepo = remember { HistoryRepository.getInstance(context) }

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("ALL") } // ALL, USER, HIGH_RAM, PROTECTED, SUSPENDED
    var sortByRam by remember { mutableStateOf(true) }
    var showDeepCleanDialog by remember { mutableStateOf(false) }
    var selectedForClean by remember { mutableStateOf<Set<String>>(emptySet()) }
    var selectedProcessDetail by remember { mutableStateOf<AppProcessInfo?>(null) }

    // Color palette for initial avatar
    val avatarColors = remember {
        listOf(
            Color(0xFF0284C7), Color(0xFF0D9488), Color(0xFF16A34A),
            Color(0xFFD97706), Color(0xFFDC2626), Color(0xFF7C3AED),
            Color(0xFFDB2777), Color(0xFF4F46E5)
        )
    }

    val filteredProcesses = remember(processes, searchQuery, selectedFilter, sortByRam) {
        val q = searchQuery.trim().lowercase()
        val list = processes.filter { p ->
            val matchSearch = q.isEmpty() ||
                    p.appName.lowercase().contains(q) ||
                    p.packageName.lowercase().contains(q)

            val matchFilter = when (selectedFilter) {
                "USER" -> !p.isSystemApp
                "HIGH_RAM" -> p.pssMb >= 150.0
                "PROTECTED" -> p.isProtected
                "SUSPENDED" -> p.isSuspended
                else -> true
            }
            matchSearch && matchFilter
        }

        if (sortByRam) {
            list.sortedByDescending { it.pssKb }
        } else {
            list.sortedBy { it.appName.lowercase() }
        }
    }

    // Killable processes for Deep Clean
    val killableProcesses = remember(processes) {
        processes.filter { !it.isProtected && !it.isSystemApp && !it.isSuspended }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(12.dp))

            // Shizuku Status Banner (Rule C.4)
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (hasShizukuPermission) Color(0xFF13202E) else Color(0xFF261919)
                ),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(
                    1.dp,
                    if (hasShizukuPermission) Color(0xFF0284C7).copy(alpha = 0.5f) else Color(0xFFDC2626).copy(alpha = 0.5f)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (hasShizukuPermission) Color(0xFF10B981) else Color(0xFFEF4444))
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = if (hasShizukuPermission) stringResource(R.string.shizuku_active) else stringResource(R.string.shizuku_disconnected),
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = if (hasShizukuPermission) stringResource(R.string.shizuku_running) else stringResource(R.string.shizuku_permission_required),
                                color = Color(0xFF94A3B8),
                                fontSize = 10.sp
                            )
                        }
                    }

                    if (!hasShizukuPermission) {
                        Button(
                            onClick = onRequestPermission,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(stringResource(R.string.shizuku_grant_permission), fontSize = 11.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // RAM Summary Card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    val totalMb = ramOverview?.totalRamMb ?: 0L
                    val usedMb = ramOverview?.usedRamMb ?: 0L
                    val freeMb = ramOverview?.freeRamMb ?: 0L
                    val usedPct = ramOverview?.usedPercentage ?: 0

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = stringResource(R.string.ram_physical),
                                color = Color(0xFF94A3B8),
                                fontSize = 11.sp
                            )
                            Text(
                                text = if (totalMb > 0) String.format("%.1f GB / %.1f GB", usedMb / 1024.0, totalMb / 1024.0) else stringResource(R.string.not_available),
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = "${usedPct}%",
                            color = if (usedPct > 80) Color(0xFFEF4444) else Color(0xFF38BDF8),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    LinearProgressIndicator(
                        progress = { (usedPct / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = if (usedPct > 80) Color(0xFFEF4444) else Color(0xFF0284C7),
                        trackColor = Color(0xFF1E293B)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${stringResource(R.string.ram_free)}: ${if (freeMb > 0) String.format("%.1f GB", freeMb / 1024.0) else stringResource(R.string.not_available)}",
                            color = Color(0xFF10B981),
                            fontSize = 10.sp
                        )

                        // Real CPU Load & Temperature (Rule C.6)
                        val cpuUsageStr = ramOverview?.cpuUsagePercent?.let { String.format("%.0f%%", it) } ?: stringResource(R.string.not_available)
                        val cpuTempStr = ramOverview?.cpuTempC?.let { String.format("%.1f°C", it) } ?: stringResource(R.string.not_available)

                        Text(
                            text = "${stringResource(R.string.cpu_load)}: $cpuUsageStr • ${stringResource(R.string.cpu_temp)}: $cpuTempStr",
                            color = Color(0xFF94A3B8),
                            fontSize = 10.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text(stringResource(R.string.search_apps), color = Color(0xFF64748B), fontSize = 12.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF64748B), modifier = Modifier.size(18.dp)) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(16.dp))
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color(0xFF141B27),
                    unfocusedContainerColor = Color(0xFF141B27),
                    focusedBorderColor = Color(0xFF0284C7),
                    unfocusedBorderColor = Color(0xFF1E293B),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Filter Chips & Sort (Rule C.4: Semua, User, Boros RAM, Dilindungi, Dibekukan)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val filterOptions = listOf(
                        "ALL" to stringResource(R.string.filter_all),
                        "USER" to stringResource(R.string.filter_user),
                        "HIGH_RAM" to stringResource(R.string.filter_high_ram),
                        "PROTECTED" to stringResource(R.string.filter_protected),
                        "SUSPENDED" to stringResource(R.string.filter_suspended)
                    )

                    filterOptions.forEach { (key, label) ->
                        FilterChip(
                            selected = selectedFilter == key,
                            onClick = { selectedFilter = key },
                            label = { Text(label, fontSize = 10.sp) },
                            shape = RoundedCornerShape(8.dp),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFF0284C7),
                                selectedLabelColor = Color.White,
                                containerColor = Color(0xFF141B27),
                                labelColor = Color(0xFF94A3B8)
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = selectedFilter == key,
                                borderColor = Color(0xFF1E293B),
                                selectedBorderColor = Color(0xFF0284C7)
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.width(4.dp))

                // Sort toggle (Rule C.4)
                IconButton(
                    onClick = { sortByRam = !sortByRam },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        if (sortByRam) Icons.Default.Sort else Icons.Default.TextFields,
                        contentDescription = if (sortByRam) stringResource(R.string.sort_ram) else stringResource(R.string.sort_name),
                        tint = Color(0xFF38BDF8),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // App Process List (Rule H.2: no duplicate keys, aggregated by package)
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentPadding = PaddingValues(bottom = 90.dp), // Rule C.5: bottom padding so Deep Clean button does not cover items
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(filteredProcesses) { process ->
                    val colorIndex = abs(process.packageName.hashCode()) % avatarColors.size
                    val avatarColor = avatarColors[colorIndex]
                    val initialLetter = process.appName.firstOrNull()?.uppercase() ?: "?"

                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedProcessDetail = process }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Colorful Initial Avatar (Rule C.4)
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(avatarColor.copy(alpha = 0.2f))
                                    .border(1.dp, avatarColor.copy(alpha = 0.5f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = initialLetter,
                                    color = avatarColor,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            // App Info
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = process.appName,
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f, fill = false)
                                    )

                                    if (process.isProtected) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(
                                            Icons.Default.Shield,
                                            contentDescription = stringResource(R.string.protected_app),
                                            tint = Color(0xFF10B981),
                                            modifier = Modifier.size(13.dp)
                                        )
                                    }

                                    if (process.isSuspended) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = stringResource(R.string.filter_suspended),
                                            color = Color(0xFFA855F7),
                                            fontSize = 8.sp,
                                            modifier = Modifier
                                                .background(Color(0xFF7E22CE).copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                                .padding(horizontal = 4.dp, vertical = 1.dp)
                                        )
                                    }
                                }

                                Text(
                                    text = process.packageName,
                                    color = Color(0xFF64748B),
                                    fontSize = 10.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )

                                if (process.protectionReason.isNotEmpty()) {
                                    Text(
                                        text = process.protectionReason,
                                        color = Color(0xFF10B981),
                                        fontSize = 9.sp
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            // RAM usage & Actions
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = process.formattedRam,
                                    color = Color(0xFF38BDF8),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                )

                                Spacer(modifier = Modifier.height(4.dp))

                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    if (!process.isProtected) {
                                        // Stop Button
                                        Button(
                                            onClick = {
                                                scope.launch {
                                                    val res = ShizukuCommandRunner.forceStopApp(process.packageName)
                                                    if (res.isSuccess) {
                                                        historyRepo.recordAction(
                                                            process.packageName,
                                                            process.appName,
                                                            CleaningAction.FORCE_STOP,
                                                            process.pssMb
                                                        )
                                                        Toast.makeText(context, "${process.appName} dihentikan", Toast.LENGTH_SHORT).show()
                                                        onRefresh()
                                                    } else {
                                                        Toast.makeText(context, "Gagal: ${res.exceptionOrNull()?.message}", Toast.LENGTH_SHORT).show()
                                                    }
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier.height(24.dp)
                                        ) {
                                            Text(stringResource(R.string.force_stop), fontSize = 9.sp, color = Color(0xFFF87171))
                                        }
                                    } else {
                                        // Shielded indicator (Rule C.2)
                                        Box(
                                            modifier = Modifier
                                                .background(Color(0xFF064E3B).copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                                                .padding(horizontal = 6.dp, vertical = 3.dp)
                                        ) {
                                            Text(stringResource(R.string.protected_app), fontSize = 9.sp, color = Color(0xFF34D399))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Floating Deep Clean Action (Rule C.3)
        if (killableProcesses.isNotEmpty()) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 16.dp)
            ) {
                Button(
                    onClick = {
                        selectedForClean = killableProcesses.map { it.packageName }.toSet()
                        showDeepCleanDialog = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                    shape = RoundedCornerShape(24.dp),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 8.dp),
                    modifier = Modifier.height(44.dp)
                ) {
                    Icon(Icons.Default.CleaningServices, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${stringResource(R.string.deep_clean)} (${killableProcesses.size})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }

        // Deep Clean Confirmation Dialog (Rule C.3)
        if (showDeepCleanDialog) {
            AlertDialog(
                onDismissRequest = { showDeepCleanDialog = false },
                containerColor = Color(0xFF141B27),
                title = {
                    Text(
                        stringResource(R.string.deep_clean_confirm_title),
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = stringResource(R.string.deep_clean_warning),
                            color = Color(0xFFFBBF24),
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        LazyColumn(modifier = Modifier.heightIn(max = 240.dp)) {
                            items(killableProcesses) { p ->
                                val isChecked = selectedForClean.contains(p.packageName)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            selectedForClean = if (isChecked) {
                                                selectedForClean - p.packageName
                                            } else {
                                                selectedForClean + p.packageName
                                            }
                                        }
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Checkbox(
                                        checked = isChecked,
                                        onCheckedChange = { checked ->
                                            selectedForClean = if (checked) {
                                                selectedForClean + p.packageName
                                            } else {
                                                selectedForClean - p.packageName
                                            }
                                        },
                                        colors = CheckboxDefaults.colors(
                                            checkedColor = Color(0xFF0284C7),
                                            uncheckedColor = Color(0xFF64748B)
                                        )
                                    )
                                    Text(
                                        text = p.appName,
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(
                                        text = p.formattedRam,
                                        color = Color(0xFF38BDF8),
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            showDeepCleanDialog = false
                            scope.launch {
                                var freedSum = 0.0
                                var cleanedCount = 0
                                selectedForClean.forEach { pkg ->
                                    val proc = killableProcesses.find { it.packageName == pkg }
                                    val res = ShizukuCommandRunner.forceStopApp(pkg)
                                    if (res.isSuccess) {
                                        freedSum += proc?.pssMb ?: 0.0
                                        cleanedCount++
                                        historyRepo.recordAction(
                                            pkg,
                                            proc?.appName ?: pkg,
                                            CleaningAction.FORCE_STOP,
                                            proc?.pssMb ?: 0.0
                                        )
                                    }
                                }
                                if (cleanedCount > 0) {
                                    historyRepo.recordAction(
                                        "batch.clean",
                                        "Deep Clean ($cleanedCount aplikasi)",
                                        CleaningAction.BATCH_BOOST,
                                        freedSum
                                    )
                                    Toast.makeText(context, "Berhasil membersihkan $cleanedCount aplikasi (~${freedSum.toInt()} MB)", Toast.LENGTH_LONG).show()
                                    onRefresh()
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(stringResource(R.string.deep_clean_action), fontSize = 11.sp)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDeepCleanDialog = false }) {
                        Text(stringResource(R.string.cancel), color = Color(0xFF94A3B8), fontSize = 11.sp)
                    }
                }
            )
        }

        // App Detail Dialog
        selectedProcessDetail?.let { proc ->
            AlertDialog(
                onDismissRequest = { selectedProcessDetail = null },
                containerColor = Color(0xFF141B27),
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(proc.appName, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        if (proc.isProtected) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(Icons.Default.Shield, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(16.dp))
                        }
                    }
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Paket: ${proc.packageName}", color = Color(0xFF94A3B8), fontSize = 11.sp)
                        Text("Alokasi RAM PSS: ${proc.formattedRam}", color = Color(0xFF38BDF8), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        if (proc.pids.isNotEmpty()) {
                            Text("PID: ${proc.pids.joinToString(", ")}", color = Color(0xFF94A3B8), fontSize = 11.sp)
                        }
                        if (proc.protectionReason.isNotEmpty()) {
                            Text("Status Perlindungan: ${proc.protectionReason}", color = Color(0xFF10B981), fontSize = 11.sp)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Toggle User Protection Button (Rule C.2)
                        Button(
                            onClick = {
                                val isNowProtected = ShizukuCommandRunner.toggleUserProtection(context, proc.packageName)
                                Toast.makeText(
                                    context,
                                    if (isNowProtected) "${proc.appName} kini dilindungi" else "${proc.appName} dilepas dari perlindungan",
                                    Toast.LENGTH_SHORT
                                ).show()
                                selectedProcessDetail = null
                                onRefresh()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Security, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (ShizukuCommandRunner.isUserProtected(context, proc.packageName)) "Lepas Perlindungan Pengguna" else "Kunci & Lindungi Aplikasi Ini",
                                fontSize = 11.sp
                            )
                        }

                        if (!proc.isProtected) {
                            // Suspend Toggle (pm suspend / pm unsuspend)
                            Button(
                                onClick = {
                                    scope.launch {
                                        val res = if (proc.isSuspended) {
                                            ShizukuCommandRunner.unsuspendApp(proc.packageName)
                                        } else {
                                            ShizukuCommandRunner.suspendApp(proc.packageName)
                                        }
                                        if (res.isSuccess) {
                                            historyRepo.recordAction(
                                                proc.packageName,
                                                proc.appName,
                                                if (proc.isSuspended) CleaningAction.UNSUSPEND else CleaningAction.SUSPEND,
                                                0.0
                                            )
                                            Toast.makeText(context, if (proc.isSuspended) "Aplikasi dipulihkan" else "Aplikasi dibekukan (pm suspend)", Toast.LENGTH_SHORT).show()
                                            selectedProcessDetail = null
                                            onRefresh()
                                        } else {
                                            Toast.makeText(context, "Gagal: ${res.exceptionOrNull()?.message}", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7E22CE)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(if (proc.isSuspended) stringResource(R.string.unsuspend) else stringResource(R.string.suspend), fontSize = 11.sp)
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { selectedProcessDetail = null }) {
                        Text(stringResource(R.string.cancel), color = Color(0xFF38BDF8), fontSize = 12.sp)
                    }
                }
            )
        }
    }
}
