package com.example.rammanager.data

import android.content.Context
import android.content.SharedPreferences
import com.example.rammanager.model.AppCleanFrequency
import com.example.rammanager.model.CleaningAction
import com.example.rammanager.model.CleaningHistoryRecord
import com.example.rammanager.model.CleaningStatsSummary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class HistoryRepository private constructor(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME = "s21fe_ram_cleaner_history"
        private const val KEY_HISTORY_DATA = "key_history_records"
        private const val MAX_RECORDS = 500

        @Volatile
        private var instance: HistoryRepository? = null

        fun getInstance(context: Context): HistoryRepository {
            return instance ?: synchronized(this) {
                instance ?: HistoryRepository(context).also { instance = it }
            }
        }
    }

    suspend fun recordAction(
        packageName: String,
        appName: String,
        action: CleaningAction,
        estimatedRamFreedMb: Double
    ): CleaningHistoryRecord = withContext(Dispatchers.IO) {
        val record = CleaningHistoryRecord(
            id = UUID.randomUUID().toString(),
            packageName = packageName,
            appName = appName,
            action = action,
            timestamp = System.currentTimeMillis(),
            estimatedRamFreedMb = estimatedRamFreedMb
        )

        val currentList = getAllHistoryInternal().toMutableList()
        currentList.add(0, record)

        if (currentList.size > MAX_RECORDS) {
            currentList.subList(MAX_RECORDS, currentList.size).clear()
        }

        saveHistoryInternal(currentList)
        record
    }

    suspend fun getAllHistory(): List<CleaningHistoryRecord> = withContext(Dispatchers.IO) {
        getAllHistoryInternal()
    }

    suspend fun clearHistory() = withContext(Dispatchers.IO) {
        prefs.edit().remove(KEY_HISTORY_DATA).apply()
    }

    suspend fun getStatsSummary(): CleaningStatsSummary = withContext(Dispatchers.IO) {
        val records = getAllHistoryInternal()
        if (records.isEmpty()) return@withContext CleaningStatsSummary()

        var totalRamFreed = 0.0
        var forceStopCount = 0
        var suspendCount = 0
        var batchBoostCount = 0

        val appCountMap = mutableMapOf<String, Pair<String, Int>>()
        val appFreedMap = mutableMapOf<String, Double>()

        records.forEach { item ->
            totalRamFreed += item.estimatedRamFreedMb
            when (item.action) {
                CleaningAction.FORCE_STOP -> forceStopCount++
                CleaningAction.SUSPEND -> suspendCount++
                CleaningAction.UNSUSPEND -> {}
                CleaningAction.BATCH_BOOST -> batchBoostCount++
            }

            val current = appCountMap[item.packageName] ?: Pair(item.appName, 0)
            appCountMap[item.packageName] = Pair(item.appName, current.second + 1)

            val currentFreed = appFreedMap[item.packageName] ?: 0.0
            appFreedMap[item.packageName] = currentFreed + item.estimatedRamFreedMb
        }

        val topApps = appCountMap.map { (pkg, pair) ->
            AppCleanFrequency(
                packageName = pkg,
                appName = pair.first,
                cleanCount = pair.second,
                totalRamFreedMb = appFreedMap[pkg] ?: 0.0
            )
        }.sortedByDescending { it.cleanCount }.take(10)

        val avgFreed = if (records.isNotEmpty()) totalRamFreed / records.size else 0.0

        CleaningStatsSummary(
            totalActions = records.size,
            totalRamFreedMb = totalRamFreed,
            forceStopCount = forceStopCount,
            suspendCount = suspendCount,
            batchBoostCount = batchBoostCount,
            topCleanedApps = topApps,
            averageFreedPerActionMb = avgFreed,
            lastCleanedTimestamp = records.firstOrNull()?.timestamp
        )
    }

    private fun getAllHistoryInternal(): List<CleaningHistoryRecord> {
        val jsonStr = prefs.getString(KEY_HISTORY_DATA, null) ?: return emptyList()
        val list = mutableListOf<CleaningHistoryRecord>()
        try {
            val jsonArray = JSONArray(jsonStr)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                val actionName = obj.optString("action", CleaningAction.FORCE_STOP.name)
                val action = try { CleaningAction.valueOf(actionName) } catch (e: Exception) { CleaningAction.FORCE_STOP }

                list.add(
                    CleaningHistoryRecord(
                        id = obj.optString("id", UUID.randomUUID().toString()),
                        packageName = obj.optString("packageName", "unknown.app"),
                        appName = obj.optString("appName", "Unknown"),
                        action = action,
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                        estimatedRamFreedMb = obj.optDouble("estimatedRamFreedMb", 0.0)
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    private fun saveHistoryInternal(list: List<CleaningHistoryRecord>) {
        try {
            val jsonArray = JSONArray()
            list.forEach { item ->
                val obj = JSONObject().apply {
                    put("id", item.id)
                    put("packageName", item.packageName)
                    put("appName", item.appName)
                    put("action", item.action.name)
                    put("timestamp", item.timestamp)
                    put("estimatedRamFreedMb", item.estimatedRamFreedMb)
                }
                jsonArray.put(obj)
            }
            prefs.edit().putString(KEY_HISTORY_DATA, jsonArray.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
