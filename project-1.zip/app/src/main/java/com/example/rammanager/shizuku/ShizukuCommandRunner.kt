package com.example.rammanager.shizuku

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import com.example.rammanager.model.AppProcessInfo
import com.example.rammanager.model.RamOverview
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

object ShizukuCommandRunner {

    const val SHIZUKU_PERMISSION_REQUEST_CODE = 1001

    fun isShizukuAvailable(): Boolean {
        return try {
            Shizuku.pingBinder()
        } catch (e: Throwable) {
            false
        }
    }

    fun hasPermission(): Boolean {
        if (!isShizukuAvailable()) return false
        return try {
            if (Shizuku.isPreV11()) false
            else Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Throwable) {
            false
        }
    }

    fun requestPermission() {
        if (isShizukuAvailable()) {
            Shizuku.requestPermission(SHIZUKU_PERMISSION_REQUEST_CODE)
        }
    }

    suspend fun executeCommand(command: String): Result<String> = withContext(Dispatchers.IO) {
        if (!isShizukuAvailable()) {
            return@withContext Result.failure(IllegalStateException("Shizuku binder is not available."))
        }
        if (!hasPermission()) {
            return@withContext Result.failure(SecurityException("Shizuku permission not granted."))
        }

        try {
            val method = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            method.isAccessible = true
            val process = method.invoke(null, arrayOf("sh", "-c", command), null, null) as Process
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val errorReader = BufferedReader(InputStreamReader(process.errorStream))
            val output = StringBuilder()
            val error = StringBuilder()

            var line: String?
            while (reader.readLine().also { line = it } != null) {
                output.appendLine(line)
            }
            while (errorReader.readLine().also { line = it } != null) {
                error.appendLine(line)
            }

            process.waitFor()
            val exitCode = process.exitValue()

            if (exitCode == 0) {
                Result.success(output.toString())
            } else {
                val errStr = error.toString().ifEmpty { output.toString() }
                Result.failure(RuntimeException("Command failed ($exitCode): $errStr"))
            }
        } catch (e: Throwable) {
            Result.failure(e)
        }
    }

    suspend fun forceStopApp(packageName: String): Result<String> = executeCommand("am force-stop $packageName")
    suspend fun suspendApp(packageName: String): Result<String> = executeCommand("pm suspend $packageName")
    suspend fun unsuspendApp(packageName: String): Result<String> = executeCommand("pm unsuspend $packageName")

    suspend fun fetchMemoryInfo(context: Context): Pair<RamOverview, List<AppProcessInfo>> = withContext(Dispatchers.IO) {
        val result = executeCommand("dumpsys meminfo")
        if (result.isFailure) return@withContext Pair(RamOverview(), emptyList())
        parseMemInfoOutput(result.getOrNull() ?: "", context)
    }

    private fun parseMemInfoOutput(rawText: String, context: Context): Pair<RamOverview, List<AppProcessInfo>> {
        val pm = context.packageManager
        val processes = mutableListOf<AppProcessInfo>()
        var totalRamKb: Long = 8L * 1024 * 1024
        var freeRamKb: Long = 3L * 1024 * 1024
        var usedRamKb: Long = 5L * 1024 * 1024
        var zramTotalKb: Long = 4L * 1024 * 1024
        var zramUsedKb: Long = 1L * 1024 * 1024

        val totalRamRegex = Regex("""Total RAM:\s+([\d,]+)K""", RegexOption.IGNORE_CASE)
        val freeRamRegex = Regex("""Free RAM:\s+([\d,]+)K""", RegexOption.IGNORE_CASE)
        val usedRamRegex = Regex("""Used RAM:\s+([\d,]+)K""", RegexOption.IGNORE_CASE)
        val zramRegex = Regex("""ZRAM:\s+([\d,]+)K.*swap\s+\(([\d,]+)K""", RegexOption.IGNORE_CASE)

        totalRamRegex.find(rawText)?.let { totalRamKb = it.groupValues[1].replace(",", "").toLongOrNull() ?: totalRamKb }
        freeRamRegex.find(rawText)?.let { freeRamKb = it.groupValues[1].replace(",", "").toLongOrNull() ?: freeRamKb }
        usedRamRegex.find(rawText)?.let { usedRamKb = it.groupValues[1].replace(",", "").toLongOrNull() ?: usedRamKb }
        zramRegex.find(rawText)?.let {
            zramUsedKb = it.groupValues[1].replace(",", "").toLongOrNull() ?: zramUsedKb
            zramTotalKb = it.groupValues[2].replace(",", "").toLongOrNull() ?: zramTotalKb
        }

        val processLineRegex = Regex("""^\s*([\d,]+)K:\s+([a-zA-Z0-9._]+)(?:\s+\(pid\s+(\d+))?""")
        var currentCategory = "Cached"

        for (line in rawText.lines()) {
            val trimmed = line.trim()
            if (trimmed.startsWith("Total PSS by OOM category:", true) || trimmed.startsWith("Total PSS by process:", true)) continue
            if (trimmed.endsWith(":")) currentCategory = trimmed.removeSuffix(":")

            val match = processLineRegex.find(line)
            if (match != null) {
                val pssKb = match.groupValues[1].replace(",", "").toLongOrNull() ?: 0L
                val processName = match.groupValues[2]
                val pid = match.groupValues[3].toIntOrNull() ?: 0
                if (!processName.contains(".")) continue

                var appLabel = processName
                var isSystem = false
                try {
                    val appInfo = pm.getApplicationInfo(processName, 0)
                    appLabel = pm.getApplicationLabel(appInfo).toString()
                    isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                } catch (e: Exception) {
                    appLabel = processName.substringAfterLast(".").replaceFirstChar { it.uppercase() }
                }

                processes.add(
                    AppProcessInfo(
                        packageName = processName,
                        appName = appLabel,
                        pid = pid,
                        pssKb = pssKb,
                        isSystemApp = isSystem,
                        isSuspended = false,
                        oomCategory = currentCategory
                    )
                )
            }
        }

        val unique = processes.sortedByDescending { it.pssKb }.distinctBy { it.packageName }
        val overview = RamOverview(
            totalRamMb = totalRamKb / 1024,
            usedRamMb = usedRamKb / 1024,
            freeRamMb = freeRamKb / 1024,
            zramTotalMb = zramTotalKb / 1024,
            zramUsedMb = zramUsedKb / 1024,
            deviceModel = "Samsung Galaxy S21 FE 5G"
        )
        return Pair(overview, unique)
    }
}
