package com.example.rammanager.shizuku

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import com.example.rammanager.model.AppProcessInfo
import com.example.rammanager.model.RamOverview
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

object ShizukuCommandRunner {

    const val SHIZUKU_PERMISSION_REQUEST_CODE = 1001

    fun isShizukuAvailable(): Boolean {
        return try {
            Shizuku.pingBinder()
        } catch (e: Throwable) {
            false
        }
    }

    fun hasPermission(): Boolean {
        if (!isShizukuAvailable()) return false
        return try {
            if (Shizuku.isPreV11()) false
            else Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Throwable) {
            false
        }
    }

    fun requestPermission() {
        if (isShizukuAvailable()) {
            Shizuku.requestPermission(SHIZUKU_PERMISSION_REQUEST_CODE)
        }
    }

    suspend fun executeCommand(command: String): Result<String> = withContext(Dispatchers.IO) {
        if (!isShizukuAvailable()) {
            return@withContext Result.failure(IllegalStateException("Shizuku binder is not available."))
        }
        if (!hasPermission()) {
            return@withContext Result.failure(SecurityException("Shizuku permission not granted."))
        }

        try {
            val method = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            method.isAccessible = true
            val process = method.invoke(null, arrayOf("sh", "-c", command), null, null) as Process
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val errorReader = BufferedReader(InputStreamReader(process.errorStream))
            val output = StringBuilder()
            val error = StringBuilder()

            var line: String?
            while (reader.readLine().also { line = it } != null) {
                output.appendLine(line)
            }
            while (errorReader.readLine().also { line = it } != null) {
                error.appendLine(line)
            }

            process.waitFor()
            val exitCode = process.exitValue()

            if (exitCode == 0) {
                Result.success(output.toString())
            } else {
                val errStr = error.toString().ifEmpty { output.toString() }
                Result.failure(RuntimeException("Command failed ($exitCode): $errStr"))
            }
        } catch (e: Throwable) {
            Result.failure(e)
        }
    }

    suspend fun forceStopApp(packageName: String): Result<String> = executeCommand("am force-stop $packageName")
    suspend fun suspendApp(packageName: String): Result<String> = executeCommand("pm suspend $packageName")
    suspend fun unsuspendApp(packageName: String): Result<String> = executeCommand("pm unsuspend $packageName")

    suspend fun setPowerProfile(mode: String): Result<String> {
        val cmd = when (mode.uppercase()) {
            "POWER_SAVER" -> "settings put global low_power 1 && cmd power set-mode 1"
            "PERFORMANCE" -> "settings put global low_power 0 && cmd power set-mode 2"
            else -> "settings put global low_power 0 && cmd power set-mode 0"
        }
        return executeCommand(cmd)
    }

    suspend fun fetchMemoryInfo(context: Context): Pair<RamOverview, List<AppProcessInfo>> = withContext(Dispatchers.IO) {
        val result = executeCommand("dumpsys meminfo")
        if (result.isFailure) return@withContext Pair(RamOverview(), emptyList())
        parseMemInfoOutput(result.getOrNull() ?: "", context)
    }

    private fun parseMemInfoOutput(rawText: String, context: Context): Pair<RamOverview, List<AppProcessInfo>> {
        val pm = context.packageManager
        val processes = mutableListOf<AppProcessInfo>()
        var totalRamKb: Long = 8L * 1024 * 1024
        var freeRamKb: Long = 3L * 1024 * 1024
        var usedRamKb: Long = 5L * 1024 * 1024
        var zramTotalKb: Long = 4L * 1024 * 1024
        var zramUsedKb: Long = 1L * 1024 * 1024

        val totalRamRegex = Regex("""Total RAM:\s+([\d,]+)K""", RegexOption.IGNORE_CASE)
        val freeRamRegex = Regex("""Free RAM:\s+([\d,]+)K""", RegexOption.IGNORE_CASE)
        val usedRamRegex = Regex("""Used RAM:\s+([\d,]+)K""", RegexOption.IGNORE_CASE)
        val zramRegex = Regex("""ZRAM:\s+([\d,]+)K.*swap\s+\(([\d,]+)K""", RegexOption.IGNORE_CASE)

        totalRamRegex.find(rawText)?.let { totalRamKb = it.groupValues[1].replace(",", "").toLongOrNull() ?: totalRamKb }
        freeRamRegex.find(rawText)?.let { freeRamKb = it.groupValues[1].replace(",", "").toLongOrNull() ?: freeRamKb }
        usedRamRegex.find(rawText)?.let { usedRamKb = it.groupValues[1].replace(",", "").toLongOrNull() ?: usedRamKb }
        zramRegex.find(rawText)?.let {
            zramUsedKb = it.groupValues[1].replace(",", "").toLongOrNull() ?: zramUsedKb
            zramTotalKb = it.groupValues[2].replace(",", "").toLongOrNull() ?: zramTotalKb
        }

        val lineRegex = Regex("""^\s*([\d,]+)K:\s+(.+?)\s*$""")
        val procRegex = Regex("""^(\S+)\s+\(pid\s+(\d+)""")
        val pkgRegex = Regex("""^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z0-9_]+)+$""")

        fun parseSection(prefix: String): List<AppProcessInfo> {
            val perPackage = LinkedHashMap<String, AppProcessInfo>()
            var section = ""
            var category = "Cached"
            for (line in rawText.lines()) {
                val trimmed = line.trim()
                if (trimmed.startsWith("Total ") && trimmed.endsWith(":")) {
                    section = trimmed
                    continue
                }
                if (!section.startsWith(prefix)) continue
                val m = lineRegex.find(line) ?: continue
                val pssKb = m.groupValues[1].replace(",", "").toLongOrNull() ?: 0L
                val rest = m.groupValues[2]
                val p = procRegex.find(rest)
                if (p == null) {
                    category = rest
                    continue
                }
                val pkg = p.groupValues[1].substringBefore(":")
                if (!pkgRegex.matches(pkg)) continue
                val existing = perPackage[pkg]
                if (existing != null) {
                    perPackage[pkg] = existing.copy(pssKb = existing.pssKb + pssKb)
                    continue
                }
                var label = pkg
                var isSystem = false
                try {
                    val appInfo = pm.getApplicationInfo(pkg, 0)
                    label = pm.getApplicationLabel(appInfo).toString()
                    isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                } catch (e: Exception) {
                    label = pkg.substringAfterLast(".").replaceFirstChar { it.uppercase() }
                }
                perPackage[pkg] = AppProcessInfo(pkg, label, p.groupValues[2].toIntOrNull() ?: 0, pssKb, isSystem, false, category)
            }
            return perPackage.values.toList()
        }

        val unique = parseSection("Total PSS by OOM adjustment")
            .ifEmpty { parseSection("Total PSS by process") }
            .sortedByDescending { it.pssKb }
        val overview = RamOverview(
            totalRamMb = totalRamKb / 1024,
            usedRamMb = usedRamKb / 1024,
            freeRamMb = freeRamKb / 1024,
            zramTotalMb = zramTotalKb / 1024,
            zramUsedMb = zramUsedKb / 1024,
            deviceModel = android.os.Build.MODEL
        )
        return Pair(overview, unique)
    }
}
