package com.example.rammanager

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rammanager.benchmark.DeviceBenchmarkEngine
import com.example.rammanager.data.BenchmarkHistoryRepository
import com.example.rammanager.model.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BenchmarkScreen(
    onBenchmarkStateChange: (isRunning: Boolean) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val engine = remember { DeviceBenchmarkEngine(context) }
    val repo = remember { BenchmarkHistoryRepository.getInstance(context) }

    var selectedMode by remember { mutableStateOf(BenchmarkMode.FAST) }
    var isRunning by remember { mutableStateOf(false) }
    var progressText by remember { mutableStateOf("") }
    var progressPercent by remember { mutableStateOf(0) }

    var currentResult by remember { mutableStateOf<BenchmarkResultRecord?>(null) }
    var previousResult by remember { mutableStateOf<BenchmarkResultRecord?>(null) }
    var averageHistoricalScore by remember { mutableStateOf(0) }
    var importedComparison by remember { mutableStateOf<ImportedBenchmarkComparison?>(null) }

    var showImportDialog by remember { mutableStateOf(false) }
    var importInputText by remember { mutableStateOf("") }
    var historyList by remember { mutableStateOf<List<BenchmarkResultRecord>>(emptyList()) }

    fun refreshHistory() {
        scope.launch {
            historyList = repo.getAllResults()
            previousResult = repo.getPreviousResult(selectedMode)
            averageHistoricalScore = repo.getAverageScore(selectedMode)
        }
    }

    LaunchedEffect(selectedMode) {
        refreshHistory()
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Mode Selector Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = stringResource(R.string.benchmark_title),
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        BenchmarkMode.values().forEach { mode ->
                            Button(
                                onClick = {
                                    if (!isRunning) {
                                        selectedMode = mode
                                        importedComparison = null
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (selectedMode == mode) Color(0xFF0284C7) else Color(0xFF1E293B)
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(vertical = 6.dp)
                            ) {
                                Text(mode.label, fontSize = 10.sp, color = Color.White, maxLines = 1)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Keep Screen On Warning (Rule E.6)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF0F172A), RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = stringResource(R.string.keep_screen_on_warning),
                            color = Color(0xFF94A3B8),
                            fontSize = 10.sp,
                            lineHeight = 14.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Start Benchmark Button
                    Button(
                        onClick = {
                            if (!isRunning) {
                                isRunning = true
                                onBenchmarkStateChange(true)
                                progressPercent = 0
                                progressText = "Menyiapkan pengujian…"
                                importedComparison = null

                                scope.launch {
                                    try {
                                        val record = engine.runBenchmark(selectedMode) { phase, pct ->
                                            progressText = phase
                                            progressPercent = pct
                                        }
                                        repo.saveResult(record)
                                        currentResult = record
                                        refreshHistory()
                                        Toast.makeText(context, "Benchmark Selesai! Skor: ${record.totalScore}", Toast.LENGTH_SHORT).show()
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Pengujian gagal: ${e.message}", Toast.LENGTH_SHORT).show()
                                    } finally {
                                        isRunning = false
                                        onBenchmarkStateChange(false)
                                    }
                                }
                            }
                        },
                        enabled = !isRunning,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isRunning) progressText else stringResource(R.string.run_benchmark),
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }

                    if (isRunning) {
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { progressPercent / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp)),
                            color = Color(0xFF38BDF8),
                            trackColor = Color(0xFF1E293B)
                        )
                    }
                }
            }
        }

        // Active Result Card
        currentResult?.let { res ->
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(res.deviceModel, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text("Mode: ${res.mode.label}", color = Color(0xFF94A3B8), fontSize = 10.sp)
                            }

                            Text(
                                text = "${res.totalScore}",
                                color = Color(0xFF38BDF8),
                                fontSize = 26.sp,
                                fontWeight = FontWeight.ExtraBold,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Stress test throttling curve (Rule E.6)
                        if (res.mode == BenchmarkMode.STRESS && res.stressCurve.isNotEmpty()) {
                            Text(
                                text = "Grafik Beban Suhu & Throttling",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFF0F172A), RoundedCornerShape(8.dp))
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                res.stressCurve.forEach { p ->
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("${p.second}s", color = Color(0xFF64748B), fontSize = 8.sp)
                                        Text("${p.score}", color = Color(0xFF38BDF8), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                        p.tempC?.let {
                                            Text(String.format("%.0f°C", it), color = Color(0xFFEF4444), fontSize = 8.sp)
                                        }
                                    }
                                }
                            }

                            res.throttlingDropPct?.let { drop ->
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Penurunan Performa (Throttling): -${String.format("%.1f%%", drop)}",
                                    color = if (drop > 15f) Color(0xFFEF4444) else Color(0xFF10B981),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                        }

                        // Raw Metrics & Variations (Rule E.3)
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            MetricRow("CPU Single-Core", "${res.singleCoreScore} poin", res.singleCoreOpsSec.formattedVariation)
                            MetricRow("CPU Multi-Core", "${res.multiCoreScore} poin", res.multiCoreOpsSec.formattedVariation)
                            if (res.mode != BenchmarkMode.STRESS) {
                                MetricRow("RAM Bandwidth", "${res.ramScore} poin", "${res.ramThroughputMbSec.formattedMedian} MB/s (${res.ramThroughputMbSec.formattedVariation})")
                                MetricRow("Storage I/O", "${res.storageScore} poin", "${res.storageThroughputMbSec.formattedMedian} MB/s (${res.storageThroughputMbSec.formattedVariation})")
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Thermal & Battery Before/After
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF0F172A), RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            val tBefore = res.tempBeforeC?.let { String.format("%.1f°C", it) } ?: "--"
                            val tAfter = res.tempAfterC?.let { String.format("%.1f°C", it) } ?: "--"
                            Text("Suhu: $tBefore ➔ $tAfter", color = Color(0xFF94A3B8), fontSize = 10.sp)
                            Text("Baterai: ${res.batteryBeforePct}% ➔ ${res.batteryAfterPct}%", color = Color(0xFF94A3B8), fontSize = 10.sp)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Comparison against own previous and historical average (Rule E.7)
                        val prev = previousResult
                        val avg = averageHistoricalScore
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Rata-rata riwayat: $avg poin",
                                color = Color(0xFF94A3B8),
                                fontSize = 10.sp
                            )
                            if (prev != null && prev.id != res.id) {
                                val diff = res.totalScore - prev.totalScore
                                Text(
                                    text = "Vs sebelumnya: ${if (diff >= 0) "+$diff" else "$diff"}",
                                    color = if (diff >= 0) Color(0xFF10B981) else Color(0xFFEF4444),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Action Buttons: Share & Import (Rule E.4, E.5)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    val shareText = res.toShareText()
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Benchmark Result", shareText))
                                    Toast.makeText(context, "Teks hasil disalin ke clipboard! Bagikan ke teman.", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(stringResource(R.string.share_result), fontSize = 10.sp)
                            }

                            Button(
                                onClick = {
                                    importInputText = ""
                                    showImportDialog = true
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(stringResource(R.string.import_result), fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }

        // Side-by-Side Comparison Card with Imported Friend Result (Rule E.5)
        importedComparison?.let { friend ->
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF10231E)),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Perbandingan Hasil Teman",
                                color = Color(0xFF34D399),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            IconButton(onClick = { importedComparison = null }, modifier = Modifier.size(20.dp)) {
                                Icon(Icons.Default.Close, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(14.dp))
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("HP Kamu:", color = Color(0xFF94A3B8), fontSize = 10.sp)
                                Text("${currentResult?.totalScore ?: 0}", color = Color(0xFF38BDF8), fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Text(currentResult?.deviceModel ?: "", color = Color.White, fontSize = 9.sp)
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text("HP Teman (${friend.deviceModel}):", color = Color(0xFF94A3B8), fontSize = 10.sp)
                                Text("${friend.totalScore}", color = Color(0xFF10B981), fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Text("Mode: ${friend.mode.name}", color = Color.White, fontSize = 9.sp)
                            }
                        }

                        currentResult?.let { myRes ->
                            Spacer(modifier = Modifier.height(6.dp))
                            val diff = myRes.totalScore - friend.totalScore
                            Text(
                                text = if (diff >= 0) "HP kamu lebih cepat +$diff poin!" else "HP teman lebih cepat +${-diff} poin!",
                                color = if (diff >= 0) Color(0xFF34D399) else Color(0xFFFBBF24),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }

        // Benchmark History Section (Rule E.7)
        if (historyList.isNotEmpty()) {
            item {
                Text(
                    text = stringResource(R.string.history_title),
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            items(historyList.take(6)) { h ->
                val df = SimpleDateFormat("dd MMM HH:mm", Locale.getDefault())
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(h.mode.label, color = Color(0xFF38BDF8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(df.format(Date(h.timestamp)), color = Color(0xFF64748B), fontSize = 9.sp)
                            }
                            Text(
                                text = "Single: ${h.singleCoreScore} • Multi: ${h.multiCoreScore}",
                                color = Color(0xFF94A3B8),
                                fontSize = 10.sp
                            )
                        }

                        Text(
                            text = "${h.totalScore}",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }

    // Import Benchmark Result Dialog (Rule E.5)
    if (showImportDialog) {
        AlertDialog(
            onDismissRequest = { showImportDialog = false },
            containerColor = Color(0xFF141B27),
            title = { Text(stringResource(R.string.import_result), color = Color.White, fontSize = 14.sp) },
            text = {
                Column {
                    Text(
                        stringResource(R.string.import_placeholder),
                        color = Color(0xFF94A3B8),
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = importInputText,
                        onValueChange = { importInputText = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF0284C7),
                            unfocusedBorderColor = Color(0xFF1E293B)
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val parsed = repo.parseAndValidateImport(importInputText)
                        if (parsed.isSuccess) {
                            val friend = parsed.getOrNull()
                            if (friend != null) {
                                if (currentResult != null && friend.mode != currentResult?.mode) {
                                    Toast.makeText(context, "Hanya bisa membandingkan mode yang sama (${currentResult?.mode?.name})", Toast.LENGTH_LONG).show()
                                } else {
                                    importedComparison = friend
                                    showImportDialog = false
                                    Toast.makeText(context, "Hasil ${friend.deviceModel} berhasil diimpor!", Toast.LENGTH_SHORT).show()
                                }
                            }
                        } else {
                            Toast.makeText(context, "Format tidak valid: ${parsed.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                ) {
                    Text(stringResource(R.string.import_btn), fontSize = 11.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = { showImportDialog = false }) {
                    Text(stringResource(R.string.cancel), color = Color(0xFF94A3B8), fontSize = 11.sp)
                }
            }
        )
    }
}

@Composable
private fun MetricRow(label: String, score: String, detail: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            Text(detail, color = Color(0xFF64748B), fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        }
        Text(score, color = Color(0xFF38BDF8), fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
}
