package com.example.rammanager.battery

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import com.example.rammanager.data.BatteryHistoryRepository
import com.example.rammanager.model.*
import com.example.rammanager.shizuku.ShizukuCommandRunner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs

class BatteryAnalyticsEngine(
    private val context: Context,
    private val historyRepository: BatteryHistoryRepository = BatteryHistoryRepository.getInstance(context)
) {
    private val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager

    suspend fun getLiveCurrentFlow(designCapacityMah: Int): BatteryCurrentFlow = withContext(Dispatchers.IO) {
        val ifilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val batteryStatus: Intent? = context.registerReceiver(null, ifilter)

        val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL

        val voltageMv = batteryStatus?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 4000) ?: 4000
        val tempRaw = batteryStatus?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 350) ?: 350
        val temperatureC = tempRaw / 10.0

        var currentMicroamps = batteryManager?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) ?: 0
        var avgCurrentMicroamps = batteryManager?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_AVERAGE) ?: 0

        var currentMa = currentMicroamps / 1000
        var avgCurrentMa = avgCurrentMicroamps / 1000

        if (!isCharging && currentMa > 0) {
            currentMa = -currentMa
        } else if (isCharging && currentMa < 0) {
            currentMa = -currentMa
        }

        val currentAvailable = currentMicroamps != 0 && currentMicroamps != Int.MIN_VALUE
        if (!currentAvailable) {
            currentMa = 0
            avgCurrentMa = 0
        }

        val powerWatts = (voltageMv.toDouble() * abs(currentMa).toDouble()) / 1_000_000.0
        val speedType = when {
            !currentAvailable -> if (isCharging) "Sedang mengisi" else "Pemakaian baterai"
            !isCharging -> "Discharging (Pemakaian Baterai)"
            powerWatts >= 20.0 -> "Fast Charging (25W Super Fast)"
            powerWatts >= 14.0 -> "Fast Charging (15W Fast)"
            powerWatts >= 8.0 -> "Normal Charging (10W Standar)"
            else -> "Slow Charging (5W USB/PC)"
        }

        BatteryCurrentFlow(
            currentNowMa = currentMa,
            currentAverageMa = avgCurrentMa,
            voltageMv = voltageMv,
            powerWatts = powerWatts,
            temperatureC = temperatureC,
            isCharging = isCharging,
            chargeSpeedType = speedType,
            currentAvailable = currentAvailable
        )
    }

    suspend fun calculateSmartEstimates(
        currentLevelPercent: Int,
        designCapacityMah: Int,
        isCharging: Boolean,
        currentMa: Int
    ): BatterySmartEstimates = withContext(Dispatchers.IO) {
        val (learnedActiveDrainRate, learnedIdleDrainRate) = historyRepository.getLearnedDrainRates()

        val timeToFull: Int?
        val timeTo80: Int?

        if (isCharging) {
            val effectiveChargeMa = if (currentMa > 300) currentMa else 2100
            val percentNeededToFull = (100 - currentLevelPercent).coerceAtLeast(0)
            val mahNeededToFull = (percentNeededToFull / 100.0) * designCapacityMah
            val saturationMultiplier = if (currentLevelPercent > 80) 1.35 else 1.1
            timeToFull = ((mahNeededToFull / effectiveChargeMa) * 60.0 * saturationMultiplier).toInt().coerceAtLeast(1)

            timeTo80 = if (currentLevelPercent < 80) {
                val mahTo80 = ((80 - currentLevelPercent) / 100.0) * designCapacityMah
                ((mahTo80 / effectiveChargeMa) * 60.0).toInt().coerceAtLeast(1)
            } else null
        } else {
            timeToFull = null
            timeTo80 = null
        }

        val screenOnHours = (currentLevelPercent / learnedActiveDrainRate).coerceAtLeast(0.1)
        val screenOnMinutes = (screenOnHours * 60).toInt()

        val screenOffHours = (currentLevelPercent / learnedIdleDrainRate).coerceAtLeast(1.0)
        val screenOffMinutes = (screenOffHours * 60).toInt()

        val mixedHours = (currentLevelPercent / (learnedActiveDrainRate * 0.25 + learnedIdleDrainRate * 0.75))
        val mixedMinutes = (mixedHours * 60).toInt()

        val activities = listOf(
            ActivityDrainEstimate("youtube", "Streaming YouTube / Netflix", "Media", 11.5, ((currentLevelPercent / 11.5) * 60).toInt()),
            ActivityDrainEstimate("gaming", "Gaming Berat (Genshin / MLBB)", "Game", 23.0, ((currentLevelPercent / 23.0) * 60).toInt()),
            ActivityDrainEstimate("social", "Sosmed (TikTok / IG / WA)", "Social", 13.8, ((currentLevelPercent / 13.8) * 60).toInt()),
            ActivityDrainEstimate("music", "Musik Offline (Layar Mati)", "Audio", 3.2, ((currentLevelPercent / 3.2) * 60).toInt()),
            ActivityDrainEstimate("calling", "Panggilan Suara (VoLTE / WA)", "Call", 5.5, ((currentLevelPercent / 5.5) * 60).toInt())
        )

        BatterySmartEstimates(timeToFull, timeTo80, screenOnMinutes, screenOffMinutes, mixedMinutes, activities)
    }

    fun readPercent(): Int {
        val i: Intent? = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        return if (level >= 0 && scale > 0) level * 100 / scale else 0
    }

    fun instantCapacityMah(percent: Int): Double? {
        if (percent < 20) return null
        val counter = batteryManager?.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER) ?: return null
        if (counter <= 0L || counter == Long.MIN_VALUE) return null
        return counter / 1000.0 / (percent / 100.0)
    }
}
