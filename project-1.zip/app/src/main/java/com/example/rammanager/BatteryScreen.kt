package com.example.rammanager

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rammanager.battery.BatteryAnalyticsEngine
import com.example.rammanager.data.BatteryHistoryRepository
import com.example.rammanager.model.*
import com.example.rammanager.service.BatteryMonitorForegroundService
import com.example.rammanager.shizuku.ShizukuCommandRunner
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BatteryScreen(
    hasShizukuPermission: Boolean,
    onRefresh: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val engine = remember { BatteryAnalyticsEngine(context) }
    val historyRepo = remember { BatteryHistoryRepository.getInstance(context) }

    var currentFlow by remember { mutableStateOf<BatteryCurrentFlow?>(null) }
    var smartEstimates by remember { mutableStateOf<BatterySmartEstimates?>(null) }
    var healthReport by remember { mutableStateOf<BatteryHealthReport?>(null) }
    var sessions by remember { mutableStateOf<List<BatterySessionRecord>>(emptyList()) }
    var designCapacityMah by remember { mutableStateOf(4500) }
    var isServiceActive by remember { mutableStateOf(BatteryMonitorForegroundService.isServiceEnabled(context)) }
    var selectedPowerProfile by remember { mutableStateOf("BALANCED") }
    var showCapacityDialog by remember { mutableStateOf(false) }
    var inputCapacityText by remember { mutableStateOf("4500") }

    val loadBatteryData = rememberUpdatedState {
        scope.launch {
            val detectedCap = ShizukuCommandRunner.getBatteryDesignCapacity(context)?.toInt() ?: 4500
            designCapacityMah = detectedCap

            val flow = engine.getLiveCurrentFlow()
            currentFlow = flow

            // Get real battery level from system Intent
            val ifilter = android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED)
            val bIntent = context.registerReceiver(null, ifilter)
            val level = bIntent?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1) ?: 80
            val scale = bIntent?.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, 100) ?: 100
            val pct = if (level >= 0 && scale > 0) (level * 100) / scale else 80

            smartEstimates = engine.calculateSmartEstimates(
                currentLevelPercent = pct,
                designCapacityMah = detectedCap,
                isCharging = flow.isCharging,
                currentMa = flow.currentNowMa
            )

            healthReport = historyRepo.getHealthReport(detectedCap)
            sessions = historyRepo.getAllSessions()
            isServiceActive = BatteryMonitorForegroundService.isServiceEnabled(context)
        }
    }

    LaunchedEffect(Unit) {
        loadBatteryData.value()
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Hero Electric Flow Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    val flow = currentFlow
                    val isCharging = flow?.isCharging == true

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                if (isCharging) Icons.Default.Bolt else Icons.Default.BatteryStd,
                                contentDescription = null,
                                tint = if (isCharging) Color(0xFF10B981) else Color(0xFF38BDF8),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isCharging) stringResource(R.string.charging) else stringResource(R.string.discharging),
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Text(
                            text = flow?.chargeSpeedType ?: "",
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Column {
                            Text(
                                text = stringResource(R.string.current),
                                color = Color(0xFF94A3B8),
                                fontSize = 11.sp
                            )
                            Text(
                                text = flow?.formattedCurrent ?: stringResource(R.string.not_available),
                                color = if (isCharging) Color(0xFF10B981) else Color(0xFF38BDF8),
                                fontSize = 24.sp,
                                fontWeight = FontWeight.ExtraBold,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = stringResource(R.string.power),
                                color = Color(0xFF94A3B8),
                                fontSize = 11.sp
                            )
                            Text(
                                text = flow?.formattedPower ?: stringResource(R.string.not_available),
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF0F172A), RoundedCornerShape(8.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${stringResource(R.string.voltage)}: ${flow?.formattedVoltage ?: stringResource(R.string.not_available)}",
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp
                        )
                        Text(
                            text = "${stringResource(R.string.temperature)}: ${flow?.formattedTemp ?: stringResource(R.string.not_available)}",
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // Time Estimates Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = if (currentFlow?.isCharging == true) stringResource(R.string.time_to_full) else stringResource(R.string.time_to_empty),
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    val est = smartEstimates
                    if (currentFlow?.isCharging == true) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Hingga 100%:", color = Color(0xFF94A3B8), fontSize = 11.sp)
                                Text(
                                    text = est?.timeToFullMinutes?.let { "~${it}m lagi" } ?: "--",
                                    color = Color(0xFF10B981),
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            est?.timeTo80PercentMinutes?.let { t80 ->
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("Alarm 80% (Proteksi):", color = Color(0xFFFBBF24), fontSize = 11.sp)
                                    Text(
                                        text = "~${t80}m lagi",
                                        color = Color(0xFFFBBF24),
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(stringResource(R.string.screen_on_est), color = Color(0xFF94A3B8), fontSize = 10.sp)
                                Text(
                                    text = est?.formatMinutes(est.timeToEmptyScreenOnMinutes) ?: "--",
                                    color = Color(0xFF38BDF8),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Column {
                                Text(stringResource(R.string.screen_off_est), color = Color(0xFF94A3B8), fontSize = 10.sp)
                                Text(
                                    text = est?.formatMinutes(est.timeToEmptyScreenOffMinutes) ?: "--",
                                    color = Color(0xFF10B981),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(stringResource(R.string.activity_estimate_general), color = Color(0xFF94A3B8), fontSize = 10.sp)
                                Text(
                                    text = est?.formatMinutes(est.timeToEmptyMixedMinutes) ?: "--",
                                    color = Color(0xFFFBBF24),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // Battery Health Card (Rule D: "Belum cukup data" if not sufficient)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.health),
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        IconButton(
                            onClick = {
                                inputCapacityText = designCapacityMah.toString()
                                showCapacityDialog = true
                            },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(Icons.Default.Settings, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(16.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    val hr = healthReport
                    if (hr != null && hr.hasSufficientData) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = hr.formattedHealth,
                                    color = Color(0xFF10B981),
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Text(
                                    text = "Status: ${hr.condition}",
                                    color = Color(0xFF94A3B8),
                                    fontSize = 11.sp
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "Kapasitas Terukur: ${hr.formattedEstimatedCapacity}",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Desain Pabrik: $designCapacityMah mAh",
                                    color = Color(0xFF94A3B8),
                                    fontSize = 10.sp
                                )
                                Text(
                                    text = "Siklus: ${hr.cycleCount} | Akurasi: ${hr.accuracyScorePercent}%",
                                    color = Color(0xFF64748B),
                                    fontSize = 9.sp
                                )
                            }
                        }
                    } else {
                        // Rule D requirement: show "Belum cukup data"
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF1E293B).copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .padding(12.dp)
                        ) {
                            Column {
                                Text(
                                    text = stringResource(R.string.insufficient_data),
                                    color = Color(0xFFFBBF24),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Dibutuhkan setidaknya 1 sesi pengisian baterai (>15%) dengan data energi terukur untuk menghitung kapasitas nyata.",
                                    color = Color(0xFF94A3B8),
                                    fontSize = 10.sp,
                                    lineHeight = 14.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Background Service & 80% Alarm Setting
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = stringResource(R.string.service_persistent),
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Layanan pemantauan arus & alarm 80% saat layar mati",
                                color = Color(0xFF94A3B8),
                                fontSize = 10.sp
                            )
                        }

                        Switch(
                            checked = isServiceActive,
                            onCheckedChange = { enabled ->
                                isServiceActive = enabled
                                if (enabled) {
                                    BatteryMonitorForegroundService.startService(context, 80)
                                    Toast.makeText(context, "Layanan latar belakang aktif", Toast.LENGTH_SHORT).show()
                                } else {
                                    BatteryMonitorForegroundService.stopService(context)
                                    Toast.makeText(context, "Layanan latar belakang dihentikan", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Color(0xFF0284C7)
                            )
                        )
                    }
                }
            }
        }

        // Power Profiles via Shizuku
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = stringResource(R.string.power_profile_title),
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val modes = listOf(
                            "POWER_SAVER" to stringResource(R.string.power_saver),
                            "BALANCED" to stringResource(R.string.power_balanced),
                            "PERFORMANCE" to stringResource(R.string.power_performance)
                        )

                        modes.forEach { (modeKey, modeLabel) ->
                            Button(
                                onClick = {
                                    selectedPowerProfile = modeKey
                                    scope.launch {
                                        val res = ShizukuCommandRunner.setPowerProfile(modeKey)
                                        if (res.isSuccess) {
                                            Toast.makeText(context, "Profil daya: $modeLabel berhasil diterapkan", Toast.LENGTH_SHORT).show()
                                        } else {
                                            Toast.makeText(context, "Hasil: ${res.exceptionOrNull()?.message}", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (selectedPowerProfile == modeKey) Color(0xFF0284C7) else Color(0xFF1E293B)
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(vertical = 6.dp)
                            ) {
                                Text(modeLabel, fontSize = 11.sp, color = Color.White)
                            }
                        }
                    }
                }
            }
        }

        // Activity Breakdown (Rule D: labeled explicitly as Perkiraan umum)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.activity_estimates_title),
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "(${stringResource(R.string.activity_estimate_general)})",
                            color = Color(0xFFFBBF24),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    smartEstimates?.activities?.forEach { act ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(act.activityName, color = Color(0xFF94A3B8), fontSize = 11.sp)
                            Text(act.formattedRemaining, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }

        // Historical Sessions List
        if (sessions.isNotEmpty()) {
            item {
                Text(
                    text = stringResource(R.string.recent_sessions_title),
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            items(sessions.take(10)) { s ->
                val df = SimpleDateFormat("dd MMM HH:mm", Locale.getDefault())
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF141B27)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = if (s.sessionType == BatterySessionType.CHARGING) "⚡ Pengisian" else "🔻 Pemakaian",
                                    color = if (s.sessionType == BatterySessionType.CHARGING) Color(0xFF10B981) else Color(0xFF38BDF8),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(df.format(Date(s.startTime)), color = Color(0xFF64748B), fontSize = 9.sp)
                            }
                            Text(
                                text = "${s.startLevelPercent}% ➔ ${s.endLevelPercent}% (${s.durationMinutes} menit)",
                                color = Color(0xFF94A3B8),
                                fontSize = 10.sp
                            )
                        }

                        Text(
                            text = if (s.sessionType == BatterySessionType.CHARGING) "+${s.formattedEnergy}" else "-${s.formattedEnergy}",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }

    // Capacity Setting Dialog
    if (showCapacityDialog) {
        AlertDialog(
            onDismissRequest = { showCapacityDialog = false },
            containerColor = Color(0xFF141B27),
            title = { Text(stringResource(R.string.battery_capacity_setting), color = Color.White, fontSize = 14.sp) },
            text = {
                Column {
                    Text(
                        stringResource(R.string.battery_capacity_hint),
                        color = Color(0xFF94A3B8),
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = inputCapacityText,
                        onValueChange = { inputCapacityText = it },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF0284C7),
                            unfocusedBorderColor = Color(0xFF1E293B)
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val cap = inputCapacityText.toFloatOrNull() ?: 4500f
                        context.getSharedPreferences("device_monitor_settings", Context.MODE_PRIVATE)
                            .edit().putFloat("user_battery_design_capacity", cap).apply()
                        designCapacityMah = cap.toInt()
                        showCapacityDialog = false
                        loadBatteryData.value()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                ) {
                    Text(stringResource(R.string.save), fontSize = 11.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCapacityDialog = false }) {
                    Text(stringResource(R.string.cancel), color = Color(0xFF94A3B8), fontSize = 11.sp)
                }
            }
        )
    }
}
