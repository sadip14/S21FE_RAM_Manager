package com.example.rammanager.benchmark

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.FileInputStream
import kotlin.math.sqrt
import kotlin.random.Random

data class RealBenchmarkScores(
    val totalScore: Int,
    val cpuScore: Int,
    val memoryScore: Int,
    val storageScore: Int,
    val uxScore: Int,
    val cpuSingleMops: Double,
    val cpuMultiGflops: Double,
    val ramBandwidthMbSec: Double,
    val storageSpeedMbSec: Double,
    val durationMs: Long
)

class DeviceBenchmarkEngine(private val context: Context) {

    suspend fun runBenchmark(onProgress: (phase: String, percent: Int) -> Unit): RealBenchmarkScores = withContext(Dispatchers.Default) {
        val startTime = System.currentTimeMillis()

        // 1. CPU Single-Core Prime Sieve Test (Integer Computation)
        onProgress("Menguji Integer & Sieve Single-Core...", 15)
        val primeStartTime = System.nanoTime()
        val primeCount = countPrimesUpTo(250_000)
        val primeElapsedSec = (System.nanoTime() - primeStartTime) / 1_000_000_000.0
        val cpuSingleMops = (250_000 / primeElapsedSec) / 1_000_000.0

        // 2. CPU Multi-Core Matrix Multiplication (Floating Point FLOPS)
        onProgress("Menguji Floating Point & Matrix GFLOPS...", 40)
        val matrixStartTime = System.nanoTime()
        val matrixSize = 350
        val opsCount = 2L * matrixSize * matrixSize * matrixSize
        runMatrixMultiplication(matrixSize)
        val matrixElapsedSec = (System.nanoTime() - matrixStartTime) / 1_000_000_000.0
        val cpuMultiGflops = (opsCount / matrixElapsedSec) / 1_000_000_000.0

        // 3. RAM Memory Bandwidth (Sequential Buffer Transfer)
        onProgress("Menguji Bandwidth RAM (LPDDR Sequential Copy)...", 65)
        val ramStartTime = System.nanoTime()
        val ramData = ByteArray(16 * 1024 * 1024)
        Random.nextBytes(ramData)
        val ramDest = ByteArray(16 * 1024 * 1024)
        for (i in 0 until 5) {
            System.arraycopy(ramData, 0, ramDest, 0, ramData.size)
        }
        val ramElapsedSec = (System.nanoTime() - ramStartTime) / 1_000_000_000.0
        val totalMbCopied = 16.0 * 5.0
        val ramBandwidthMbSec = totalMbCopied / ramElapsedSec

        // 4. Storage Sequential Read/Write Test
        onProgress("Menguji Kecepatan I/O Penyimpanan Internal...", 88)
        val storageStartTime = System.nanoTime()
        val tempFile = File(context.cacheDir, "benchmark_io.tmp")
        val testPayload = ByteArray(8 * 1024 * 1024)
        Random.nextBytes(testPayload)
        
        FileOutputStream(tempFile).use { fos ->
            fos.write(testPayload)
            fos.flush()
        }
        val readBuffer = ByteArray(8 * 1024 * 1024)
        FileInputStream(tempFile).use { fis ->
            fis.read(readBuffer)
        }
        tempFile.delete()
        val storageElapsedSec = (System.nanoTime() - storageStartTime) / 1_000_000_000.0
        val storageSpeedMbSec = 16.0 / storageElapsedSec

        onProgress("Menghitung Skor AnTuTu Equivalen...", 100)
        val totalDuration = System.currentTimeMillis() - startTime

        val cpuScore = (cpuSingleMops * 22_000 + cpuMultiGflops * 48_000).toInt().coerceIn(120_000, 480_000)
        val memoryScore = (ramBandwidthMbSec * 38.0).toInt().coerceIn(80_000, 260_000)
        val storageScore = (storageSpeedMbSec * 450.0).toInt().coerceIn(60_000, 220_000)
        val uxScore = ((cpuScore + memoryScore) * 0.35).toInt().coerceIn(70_000, 200_000)
        val totalScore = cpuScore + memoryScore + storageScore + uxScore

        RealBenchmarkScores(
            totalScore = totalScore,
            cpuScore = cpuScore,
            memoryScore = memoryScore,
            storageScore = storageScore,
            uxScore = uxScore,
            cpuSingleMops = (cpuSingleMops * 100).toInt() / 100.0,
            cpuMultiGflops = (cpuMultiGflops * 100).toInt() / 100.0,
            ramBandwidthMbSec = (ramBandwidthMbSec * 10).toInt() / 10.0,
            storageSpeedMbSec = (storageSpeedMbSec * 10).toInt() / 10.0,
            durationMs = totalDuration
        )
    }

    private fun countPrimesUpTo(limit: Int): Int {
        val isPrime = BooleanArray(limit + 1) { true }
        isPrime[0] = false
        isPrime[1] = false
        val sqrtLimit = sqrt(limit.toDouble()).toInt()
        for (p in 2..sqrtLimit) {
            if (isPrime[p]) {
                var multiple = p * p
                while (multiple <= limit) {
                    isPrime[multiple] = false
                    multiple += p
                }
            }
        }
        var count = 0
        for (p in 2..limit) {
            if (isPrime[p]) count++
        }
        return count
    }

    private fun runMatrixMultiplication(n: Int) {
        val a = Array(n) { FloatArray(n) { 1.05f } }
        val b = Array(n) { FloatArray(n) { 0.95f } }
        val c = Array(n) { FloatArray(n) }
        for (i in 0 until n) {
            for (k in 0 until n) {
                val aik = a[i][k]
                for (j in 0 until n) {
                    c[i][j] += aik * b[k][j]
                }
            }
        }
    }
}
