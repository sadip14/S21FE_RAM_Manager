package com.example.rammanager.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.rammanager.MainActivity
import com.example.rammanager.data.BatteryHistoryRepository
import com.example.rammanager.model.BatterySessionRecord
import com.example.rammanager.model.BatterySessionType
import com.example.rammanager.model.DESIGN_CAPACITY_MAH
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.math.abs

class BatteryMonitorForegroundService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private lateinit var historyRepo: BatteryHistoryRepository

    private var sessionActive = false
    private var isCharging = false
    private var sessionStartTime = 0L
    private var sessionStartLevel = 0
    private var sessionStartCounterUah = -1L
    private var lastSampleTime = 0L
    private var integratedMah = 0.0
    private var currentSum = 0L
    private var currentSamples = 0
    private var peakTempC = 0.0
    private var targetAlarmLevel = 80
    private var hasTriggeredAlarm = false

    companion object {
        const val PREFS = "s21fe_battery_analytics_history"
        const val KEY_ENABLED = "key_auto_start_background_service"
        const val CHANNEL_ID = "channel_battery_monitor_persistent"
        const val ALARM_CHANNEL_ID = "channel_battery_alarm_high"
        const val NOTIFICATION_ID = 2001
        const val ALARM_NOTIFICATION_ID = 2002
        const val ACTION_START_SERVICE = "com.example.rammanager.action.START_SERVICE"
        const val ACTION_STOP_SERVICE = "com.example.rammanager.action.STOP_SERVICE"
        const val EXTRA_TARGET_ALARM = "extra_target_alarm"

        fun startService(context: Context, targetAlarm: Int = 80) {
            val intent = Intent(context, BatteryMonitorForegroundService::class.java).apply {
                action = ACTION_START_SERVICE
                putExtra(EXTRA_TARGET_ALARM, targetAlarm)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
            else context.startService(intent)
        }

        fun stopService(context: Context) {
            context.stopService(Intent(context, BatteryMonitorForegroundService::class.java))
        }
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_BATTERY_CHANGED) handleBatteryUpdate(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        historyRepo = BatteryHistoryRepository.getInstance(applicationContext)
        createNotificationChannels()
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_SERVICE) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        targetAlarmLevel = intent?.getIntExtra(EXTRA_TARGET_ALARM, 80) ?: 80
        startForeground(NOTIFICATION_ID, buildNotification("Monitor baterai aktif", "Memuat data sensor..."))
        registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.let { handleBatteryUpdate(it) }
        return START_STICKY
    }

    private fun handleBatteryUpdate(intent: Intent) {
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        if (level < 0 || scale <= 0) return
        val percent = level * 100 / scale

        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val nowCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        val tempC = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0
        val voltageMv = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)

        val bm = getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val rawUa = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) ?: 0
        val hasCurrent = rawUa != 0 && rawUa != Int.MIN_VALUE
        var currentMa = if (hasCurrent) rawUa / 1000 else 0
        if (!nowCharging && currentMa > 0) currentMa = -currentMa
        if (nowCharging && currentMa < 0) currentMa = -currentMa
        val counterRaw = bm?.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER) ?: -1L
        val counter = if (counterRaw > 0L && counterRaw != Long.MIN_VALUE) counterRaw else -1L
        val now = System.currentTimeMillis()

        if (!sessionActive || isCharging != nowCharging) {
            if (sessionActive) finalizeSession(isCharging, now, percent, counter)
            startSession(nowCharging, now, percent, counter)
        } else if (hasCurrent && lastSampleTime > 0L) {
            val dtHours = (now - lastSampleTime).coerceAtMost(10 * 60 * 1000L) / 3_600_000.0
            integratedMah += abs(currentMa) * dtHours
        }
        if (hasCurrent) {
            currentSum += currentMa
            currentSamples++
        }
        if (tempC > peakTempC) peakTempC = tempC
        lastSampleTime = now

        if (nowCharging && percent >= targetAlarmLevel && !hasTriggeredAlarm) {
            hasTriggeredAlarm = true
            triggerChargeAlarm(percent)
        }

        val currentStr = if (!hasCurrent) "arus n/a" else if (currentMa >= 0) "+$currentMa mA" else "$currentMa mA"
        val powerStr = String.format("%.1f W", if (hasCurrent && voltageMv > 0) abs(currentMa) * voltageMv / 1_000_000.0 else 0.0)
        val tempStr = String.format("%.1f C", tempC)
        val title = if (nowCharging) "$percent% | $currentStr | $powerStr" else "$percent% | $currentStr | $tempStr"

        serviceScope.launch {
            val text = if (nowCharging) {
                if (percent >= 100) "Penuh"
                else if (hasCurrent && currentMa > 300) {
                    val mins = ((100 - percent) / 100.0 * DESIGN_CAPACITY_MAH / currentMa * 60).toInt().coerceAtLeast(1)
                    "~$mins mnt hingga penuh (perkiraan)"
                } else "Sedang mengisi daya"
            } else if (historyRepo.hasDischargeData()) {
                val rate = historyRepo.getLearnedDrainRates().first
                String.format("Sisa ~%.1f jam (berdasarkan pemakaianmu)", percent / rate)
            } else "Mengumpulkan data pemakaian..."
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIFICATION_ID, buildNotification(title, text))
        }
    }

    private fun startSession(charging: Boolean, now: Long, percent: Int, counter: Long) {
        sessionActive = true
        isCharging = charging
        sessionStartTime = now
        sessionStartLevel = percent
        sessionStartCounterUah = counter
        integratedMah = 0.0
        currentSum = 0L
        currentSamples = 0
        peakTempC = 0.0
        hasTriggeredAlarm = false
        lastSampleTime = 0L
    }

    private fun finalizeSession(charging: Boolean, endT: Long, endP: Int, endCounter: Long) {
        val delta = abs(endP - sessionStartLevel)
        val durMins = ((endT - sessionStartTime) / 60_000L).toInt().coerceAtLeast(1)
        if (delta < 3 && durMins < 10) return
        val energy = when {
            sessionStartCounterUah > 0 && endCounter > 0 -> abs(endCounter - sessionStartCounterUah) / 1000.0
            integratedMah > 0.0 -> integratedMah
            else -> 0.0
        }
        if (charging && energy <= 0.0) return
        val record = BatterySessionRecord(
            id = "svc-" + UUID.randomUUID().toString().substring(0, 8),
            sessionType = if (charging) BatterySessionType.CHARGING else BatterySessionType.DISCHARGING,
            startTime = sessionStartTime,
            endTime = endT,
            durationMinutes = durMins,
            startLevelPercent = sessionStartLevel,
            endLevelPercent = endP,
            energyMah = energy,
            avgCurrentMa = if (currentSamples > 0) (currentSum / currentSamples).toInt() else 0,
            peakTemperatureC = peakTempC
        )
        serviceScope.launch { historyRepo.recordSession(record) }
    }

    private fun triggerChargeAlarm(percent: Int) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val pi = PendingIntent.getActivity(this, 102, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, ALARM_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle("Baterai mencapai $percent%")
            .setContentText("Cabut charger untuk mengurangi keausan baterai.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(ALARM_NOTIFICATION_ID, n)
    }

    private fun buildNotification(title: String, text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_charging)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(pi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Monitor Baterai", NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) }
            )
            nm.createNotificationChannel(
                NotificationChannel(ALARM_CHANNEL_ID, "Alarm Pengisian", NotificationManager.IMPORTANCE_HIGH)
            )
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(batteryReceiver) } catch (_: Exception) {}
        serviceScope.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
