package com.example.rammanager.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.rammanager.MainActivity
import com.example.rammanager.data.BatteryHistoryRepository
import com.example.rammanager.model.BatterySessionRecord
import com.example.rammanager.model.BatterySessionType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.UUID

/**
 * Ultra-lightweight, battery-friendly Android Foreground Service.
 * Measures real electrical current flow and session charge delta without artificial values.
 */
class BatteryMonitorForegroundService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private lateinit var historyRepo: BatteryHistoryRepository
    private var lastLevel: Int = -1
    private var isCharging: Boolean = false
    private var sessionStartTime: Long = 0L
    private var sessionStartLevel: Int = 0
    private var sessionStartChargeCounterUah: Int = 0
    private var currentSumSamples: Long = 0L
    private var currentSampleCount: Int = 0
    private var targetAlarmLevel: Int = 80
    private var hasTriggeredAlarm: Boolean = false

    companion object {
        const val CHANNEL_ID = "channel_battery_monitor_persistent"
        const val ALARM_CHANNEL_ID = "channel_battery_alarm_high"
        const val NOTIFICATION_ID = 2001
        const val ALARM_NOTIFICATION_ID = 2002

        const val ACTION_START_SERVICE = "com.example.rammanager.action.START_SERVICE"
        const val ACTION_STOP_SERVICE = "com.example.rammanager.action.STOP_SERVICE"
        const val EXTRA_TARGET_ALARM = "extra_target_alarm"

        const val PREFS_SERVICE_STATE = "device_monitor_service_state"
        const val KEY_SERVICE_ENABLED = "key_service_enabled"

        fun startService(context: Context, targetAlarm: Int = 80) {
            context.getSharedPreferences(PREFS_SERVICE_STATE, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_SERVICE_ENABLED, true).apply()

            val intent = Intent(context, BatteryMonitorForegroundService::class.java).apply {
                action = ACTION_START_SERVICE
                putExtra(EXTRA_TARGET_ALARM, targetAlarm)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            context.getSharedPreferences(PREFS_SERVICE_STATE, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_SERVICE_ENABLED, false).apply()

            val intent = Intent(context, BatteryMonitorForegroundService::class.java).apply {
                action = ACTION_STOP_SERVICE
            }
            context.stopService(intent)
        }

        fun isServiceEnabled(context: Context): Boolean {
            return context.getSharedPreferences(PREFS_SERVICE_STATE, Context.MODE_PRIVATE)
                .getBoolean(KEY_SERVICE_ENABLED, false) // Default is FALSE (Rule H.4)
        }
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_BATTERY_CHANGED) {
                handleBatteryUpdate(intent)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        historyRepo = BatteryHistoryRepository.getInstance(applicationContext)
        createNotificationChannels()

        val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        registerReceiver(batteryReceiver, filter)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_SERVICE) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        targetAlarmLevel = intent?.getIntExtra(EXTRA_TARGET_ALARM, 80) ?: 80

        val initialNotification = buildPersistentNotification(
            level = 80,
            currentMa = null,
            powerWatts = null,
            tempC = null,
            isCharging = false,
            timeEstimateStr = "Memantau sensor baterai…"
        )
        startForeground(NOTIFICATION_ID, initialNotification)

        return START_STICKY
    }

    private fun handleBatteryUpdate(intent: Intent) {
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val percent = if (level >= 0 && scale > 0) (level * 100) / scale else 0

        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val nowCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL

        val voltageMv = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1).let {
            if (it > 0) it else null
        }
        val tempRaw = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1)
        val tempC = if (tempRaw > 0) tempRaw / 10.0 else null

        val bm = getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val rawCurrentUa = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) ?: 0
        var currentMa: Int? = if (rawCurrentUa != 0) rawCurrentUa / 1000 else null

        if (currentMa != null) {
            if (!nowCharging && currentMa > 0) currentMa = -currentMa
            if (nowCharging && currentMa < 0) currentMa = -currentMa
            currentSumSamples += kotlin.math.abs(currentMa)
            currentSampleCount++
        }

        val powerWatts = if (voltageMv != null && currentMa != null) {
            (voltageMv.toDouble() * kotlin.math.abs(currentMa).toDouble()) / 1_000_000.0
        } else null

        // Detect session transition
        if (isCharging != nowCharging) {
            if (sessionStartTime > 0 && lastLevel >= 0) {
                finalizeSession(isCharging, sessionStartTime, System.currentTimeMillis(), sessionStartLevel, percent, bm)
            }
            sessionStartTime = System.currentTimeMillis()
            sessionStartLevel = percent
            sessionStartChargeCounterUah = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER) ?: 0
            currentSumSamples = 0L
            currentSampleCount = 0
            isCharging = nowCharging
            hasTriggeredAlarm = false
        }

        // 80% charge level alarm
        if (nowCharging && percent >= targetAlarmLevel && !hasTriggeredAlarm) {
            hasTriggeredAlarm = true
            triggerChargeAlarm(percent)
        }

        val estimateStr = if (nowCharging) {
            if (currentMa != null && currentMa > 200) {
                val designMah = getSharedPreferences("device_monitor_settings", Context.MODE_PRIVATE)
                    .getFloat("user_battery_design_capacity", 0f).toInt().let { if (it > 0) it else 4500 }
                val mins = ((100 - percent) * designMah / 100 * 60) / currentMa
                "~${mins.coerceAtLeast(1)}m hingga penuh"
            } else {
                "Mengisi daya ($percent%)"
            }
        } else {
            val hrs = (percent / 13.5)
            String.format("Sisa ~%.1fj daya", hrs)
        }

        lastLevel = percent

        val notification = buildPersistentNotification(percent, currentMa, powerWatts, tempC, nowCharging, estimateStr)
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, notification)
    }

    private fun triggerChargeAlarm(percent: Int) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val intent = Intent(this, MainActivity::class.java)
        val pi = PendingIntent.getActivity(this, 102, intent, PendingIntent.FLAG_IMMUTABLE)

        val alarmNotif = NotificationCompat.Builder(this, ALARM_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle("Baterai Mencapai $percent%!")
            .setContentText("Disarankan cabut pengisi daya sekarang untuk menjaga kesehatan baterai.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()

        nm.notify(ALARM_NOTIFICATION_ID, alarmNotif)
    }

    /**
     * Finalizes session using real measured energy (Charge counter or numerical integration).
     * Rule H.5: Sessions without real energy data are NOT recorded.
     */
    private fun finalizeSession(
        charging: Boolean,
        startT: Long,
        endT: Long,
        startP: Int,
        endP: Int,
        bm: BatteryManager?
    ) {
        val delta = kotlin.math.abs(endP - startP)
        val durMins = ((endT - startT) / (1000 * 60)).toInt().coerceAtLeast(1)

        val endChargeCounterUah = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER) ?: 0
        var measuredEnergyMah: Double? = null

        // Method 1: Accurate kernel charge counter difference
        if (sessionStartChargeCounterUah > 0 && endChargeCounterUah > 0) {
            val diffUah = kotlin.math.abs(endChargeCounterUah - sessionStartChargeCounterUah)
            if (diffUah > 1000) {
                measuredEnergyMah = diffUah / 1000.0
            }
        }

        // Method 2: Numerical integration of actual measured current over time
        if (measuredEnergyMah == null && currentSampleCount > 0) {
            val avgMa = currentSumSamples / currentSampleCount
            if (avgMa > 0) {
                measuredEnergyMah = avgMa * (durMins / 60.0)
            }
        }

        // Only record if energy was actually measured (Rule H.5)
        if (measuredEnergyMah != null && measuredEnergyMah > 10.0 && (delta >= 5 || durMins >= 10)) {
            val avgMa = if (currentSampleCount > 0) (currentSumSamples / currentSampleCount).toInt() else null
            serviceScope.launch {
                val record = BatterySessionRecord(
                    id = "session-${UUID.randomUUID().toString().substring(0, 8)}",
                    sessionType = if (charging) BatterySessionType.CHARGING else BatterySessionType.DISCHARGING,
                    startTime = startT,
                    endTime = endT,
                    durationMinutes = durMins,
                    startLevelPercent = startP,
                    endLevelPercent = endP,
                    energyMah = measuredEnergyMah,
                    avgCurrentMa = if (charging) avgMa else (avgMa?.let { -it }),
                    peakTemperatureC = null
                )
                historyRepo.recordSession(record)
            }
        }
    }

    private fun buildPersistentNotification(
        level: Int,
        currentMa: Int?,
        powerWatts: Double?,
        tempC: Double?,
        isCharging: Boolean,
        timeEstimateStr: String
    ): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val currentStr = currentMa?.let { if (it >= 0) "+$it mA" else "$it mA" } ?: "Sensor siap"
        val powerStr = powerWatts?.let { String.format(" • %.1fW", it) } ?: ""
        val tempStr = tempC?.let { String.format(" • %.1f°C", it) } ?: ""

        val title = if (isCharging) {
            "⚡ Monitor Baterai: $level% ($currentStr$powerStr)"
        } else {
            "🔋 Monitor Baterai: $level% ($currentStr$tempStr)"
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_charging)
            .setContentTitle(title)
            .setContentText(timeEstimateStr)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val channel = NotificationChannel(
                CHANNEL_ID,
                "Monitor Baterai Berjalan",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notifikasi status arus dan waktu pengisian baterai."
                setShowBadge(false)
            }
            nm.createNotificationChannel(channel)

            val alarmChannel = NotificationChannel(
                ALARM_CHANNEL_ID,
                "Alarm Proteksi Baterai (80%)",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alarm notifikasi saat baterai mencapai 80%."
            }
            nm.createNotificationChannel(alarmChannel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(batteryReceiver)
        } catch (e: Exception) {}
        serviceScope.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
