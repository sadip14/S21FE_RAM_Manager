package com.example.rammanager

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rammanager.model.AppProcessInfo
import com.example.rammanager.model.CleaningAction
import com.example.rammanager.model.CleaningHistoryRecord
import com.example.rammanager.model.CleaningStatsSummary
import com.example.rammanager.model.RamOverview
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

internal val CardBg = Color(0xFF111827)
internal val Muted = Color(0xFF94A3B8)
internal val Accent = Color(0xFF38BDF8)

@Composable
internal fun InfoCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CardBg)
    ) {
        Column(modifier = Modifier.padding(14.dp), content = content)
    }
}

@Composable
fun MonitorScreen(
    isShizukuActive: Boolean,
    hasShizukuPermission: Boolean,
    onRequestPermission: () -> Unit,
    ramOverview: RamOverview,
    isRefreshing: Boolean,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    selectedFilter: FilterType,
    onFilterChange: (FilterType) -> Unit,
    filteredList: List<AppProcessInfo>,
    onForceStop: (AppProcessInfo) -> Unit,
    onToggleSuspend: (AppProcessInfo) -> Unit
) {
    if (!isShizukuActive || !hasShizukuPermission) {
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                if (!isShizukuActive) "Shizuku belum aktif" else "Izin Shizuku belum diberikan",
                color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "Jalankan Shizuku (Wireless Debugging), lalu beri izin ke app ini.",
                color = Muted, fontSize = 13.sp
            )
            if (isShizukuActive) {
                Spacer(Modifier.height(16.dp))
                Button(onClick = onRequestPermission) { Text("Minta Izin Shizuku") }
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 88.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                InfoCard {
                    val total = ramOverview.totalRamMb.coerceAtLeast(1L)
                    Text(
                        "RAM ${ramOverview.usedRamMb} / ${ramOverview.totalRamMb} MB",
                        color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { (ramOverview.usedRamMb.toFloat() / total).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth(),
                        color = Accent
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Free ${ramOverview.freeRamMb} MB \u2022 ZRAM ${ramOverview.zramUsedMb}/${ramOverview.zramTotalMb} MB",
                        color = Muted, fontSize = 12.sp
                    )
                    if (isRefreshing) {
                        Spacer(Modifier.height(6.dp))
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    }
                }
            }
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchChange,
                    singleLine = true,
                    label = { Text("Cari app") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            item {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterType.values().forEach { f ->
                        FilterChip(
                            selected = selectedFilter == f,
                            onClick = { onFilterChange(f) },
                            label = { Text(f.label, fontSize = 12.sp) }
                        )
                    }
                }
            }
            items(filteredList) { app ->
                InfoCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                app.appName, color = Color.White, fontWeight = FontWeight.SemiBold,
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                app.packageName, color = Muted, fontSize = 11.sp,
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                app.formattedRam + " \u2022 " + app.oomCategory +
                                    (if (app.isSuspended) " \u2022 Suspended" else ""),
                                color = Accent, fontSize = 12.sp
                            )
                        }
                        TextButton(onClick = { onToggleSuspend(app) }) {
                            Text(if (app.isSuspended) "Resume" else "Suspend", fontSize = 12.sp)
                        }
                        Button(
                            onClick = { onForceStop(app) },
                            contentPadding = PaddingValues(horizontal = 12.dp)
                        ) { Text("Stop", fontSize = 12.sp) }
                    }
                }
            }
        }
    }
}

@Composable
fun HistoryAndStatsScreen(
    statsSummary: CleaningStatsSummary,
    historyList: List<CleaningHistoryRecord>,
    selectedActionFilter: CleaningAction?,
    onActionFilterSelected: (CleaningAction?) -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()) }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            InfoCard {
                Text(
                    "Total dibersihkan: ${statsSummary.formattedTotalFreed}",
                    color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "${statsSummary.totalActions} aksi \u2022 rata-rata ${statsSummary.formattedAvgFreed}/aksi",
                    color = Muted, fontSize = 12.sp
                )
                Text(
                    "Force stop ${statsSummary.forceStopCount} \u2022 Suspend ${statsSummary.suspendCount} \u2022 Boost ${statsSummary.batchBoostCount}",
                    color = Muted, fontSize = 12.sp
                )
            }
        }
        if (statsSummary.topCleanedApps.isNotEmpty()) {
            item {
                InfoCard {
                    Text("App paling sering dibersihkan", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(4.dp))
                    statsSummary.topCleanedApps.take(5).forEach { a ->
                        Text(
                            "${a.appName} \u2014 ${a.cleanCount}x (${a.formattedTotalFreed})",
                            color = Muted, fontSize = 12.sp
                        )
                    }
                }
            }
        }
        item {
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedActionFilter == null,
                    onClick = { onActionFilterSelected(null) },
                    label = { Text("Semua", fontSize = 12.sp) }
                )
                CleaningAction.values().forEach { a ->
                    FilterChip(
                        selected = selectedActionFilter == a,
                        onClick = { onActionFilterSelected(a) },
                        label = { Text(a.displayName, fontSize = 12.sp) }
                    )
                }
            }
        }
        items(historyList) { r ->
            InfoCard {
                Text(r.appName, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    "${r.action.displayName} \u2022 ${r.formattedRamFreed} \u2022 ${dateFormat.format(Date(r.timestamp))}",
                    color = Muted, fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
fun ShellConsoleScreen(
    isShizukuActive: Boolean,
    hasPermission: Boolean,
    command: String,
    onCommandChange: (String) -> Unit,
    output: String,
    onExecute: (String) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        OutlinedTextField(
            value = command,
            onValueChange = onCommandChange,
            label = { Text("Perintah shell") },
            modifier = Modifier.fillMaxWidth()
        )
        Button(
            onClick = { onExecute(command) },
            enabled = isShizukuActive && hasPermission && command.isNotBlank()
        ) { Text("Jalankan via Shizuku") }
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color(0xFF020617), RoundedCornerShape(10.dp))
                .padding(10.dp)
        ) {
            Text(
                output.ifEmpty { "Output muncul di sini" },
                color = Color(0xFF86EFAC),
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                modifier = Modifier.verticalScroll(rememberScrollState())
            )
        }
    }
}
