package com.example.rammanager.model

enum class CleaningAction(val displayName: String) {
    FORCE_STOP("Force Stop"),
    SUSPEND("Suspend"),
    UNSUSPEND("Unsuspend"),
    BATCH_BOOST("Deep Clean Boost")
}

data class CleaningHistoryRecord(
    val id: String,
    val packageName: String,
    val appName: String,
    val action: CleaningAction,
    val timestamp: Long,
    val estimatedRamFreedMb: Double
) {
    val formattedRamFreed: String
        get() = when {
            estimatedRamFreedMb <= 0.0 -> "0 MB"
            estimatedRamFreedMb >= 1024.0 -> String.format("%.2f GB", estimatedRamFreedMb / 1024.0)
            else -> String.format("%.1f MB", estimatedRamFreedMb)
        }
}

data class AppCleanFrequency(
    val packageName: String,
    val appName: String,
    val cleanCount: Int,
    val totalRamFreedMb: Double
) {
    val formattedTotalFreed: String
        get() = when {
            totalRamFreedMb >= 1024.0 -> String.format("%.2f GB", totalRamFreedMb / 1024.0)
            else -> String.format("%.1f MB", totalRamFreedMb)
        }
}

data class CleaningStatsSummary(
    val totalActions: Int = 0,
    val totalRamFreedMb: Double = 0.0,
    val forceStopCount: Int = 0,
    val suspendCount: Int = 0,
    val batchBoostCount: Int = 0,
    val topCleanedApps: List<AppCleanFrequency> = emptyList(),
    val averageFreedPerActionMb: Double = 0.0,
    val lastCleanedTimestamp: Long? = null
) {
    val formattedTotalFreed: String
        get() = when {
            totalRamFreedMb >= 1024.0 -> String.format("%.2f GB", totalRamFreedMb / 1024.0)
            else -> String.format("%.1f MB", totalRamFreedMb)
        }

    val formattedAvgFreed: String
        get() = when {
            averageFreedPerActionMb >= 1024.0 -> String.format("%.2f GB", averageFreedPerActionMb / 1024.0)
            else -> String.format("%.1f MB", averageFreedPerActionMb)
        }
}
