package com.example.rammanager.model

data class AppProcessInfo(
    val packageName: String,
    val appName: String,
    val pid: Int,
    val pssKb: Long,
    val isSystemApp: Boolean,
    val isSuspended: Boolean,
    val oomCategory: String
) {
    val pssMb: Double
        get() = pssKb / 1024.0

    val formattedRam: String
        get() = if (pssMb >= 1024.0) String.format("%.2f GB", pssMb / 1024.0)
        else String.format("%.1f MB", pssMb)
}

data class RamOverview(
    val totalRamMb: Long = 0L,
    val usedRamMb: Long = 0L,
    val freeRamMb: Long = 0L,
    val zramTotalMb: Long = 0L,
    val zramUsedMb: Long = 0L,
    val deviceModel: String = ""
)
