package com.example.rammanager.model

data class AppProcessInfo(
    val packageName: String,
    val appName: String,
    val pids: List<Int>,
    val pssKb: Long,
    val isSystemApp: Boolean,
    val isProtected: Boolean,
    val protectionReason: String,
    val isSuspended: Boolean,
    val oomCategory: String
) {
    val pssMb: Double
        get() = pssKb / 1024.0

    val formattedRam: String
        get() = if (pssMb >= 1024.0) String.format("%.2f GB", pssMb / 1024.0)
        else String.format("%.1f MB", pssMb)
}

data class RamOverview(
    val totalRamMb: Long = 0L,
    val usedRamMb: Long = 0L,
    val freeRamMb: Long = 0L,
    val zramTotalMb: Long = 0L,
    val zramUsedMb: Long = 0L,
    val cpuUsagePercent: Float? = null,
    val cpuTempC: Float? = null
) {
    val usedPercentage: Int
        get() = if (totalRamMb > 0L) ((usedRamMb * 100L) / totalRamMb).toInt() else 0
}
