package com.example.rammanager

import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.rammanager.data.HistoryRepository
import com.example.rammanager.model.AppProcessInfo
import com.example.rammanager.model.CleaningAction
import com.example.rammanager.model.CleaningHistoryRecord
import com.example.rammanager.model.CleaningStatsSummary
import com.example.rammanager.model.RamOverview
import com.example.rammanager.shizuku.ShizukuCommandRunner
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        isShizukuActiveState.value = ShizukuCommandRunner.isShizukuAvailable()
        hasPermissionState.value = ShizukuCommandRunner.hasPermission()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        isShizukuActiveState.value = false
        hasPermissionState.value = false
    }

    private val requestPermissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == ShizukuCommandRunner.SHIZUKU_PERMISSION_REQUEST_CODE) {
                val granted = grantResult == PackageManager.PERMISSION_GRANTED
                hasPermissionState.value = granted
                if (granted) {
                    Toast.makeText(this, "Shizuku permission granted!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Shizuku permission denied.", Toast.LENGTH_LONG).show()
                }
            }
        }

    private val isShizukuActiveState = mutableStateOf(false)
    private val hasPermissionState = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        Shizuku.addRequestPermissionResultListener(requestPermissionResultListener)

        isShizukuActiveState.value = ShizukuCommandRunner.isShizukuAvailable()
        hasPermissionState.value = ShizukuCommandRunner.hasPermission()

        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF38BDF8), onPrimary = Color(0xFF0F172A))) {
            S21FERamManagerApp(
                isShizukuActive = isShizukuActiveState.value,
                hasShizukuPermission = hasPermissionState.value,
                onRequestPermission = {
                    ShizukuCommandRunner.requestPermission()
                }
            )
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        Shizuku.removeBinderReceivedListener(binderReceivedListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        Shizuku.removeRequestPermissionResultListener(requestPermissionResultListener)
    }
}

enum class NavigationTab(val title: String, val icon: ImageVector) {
    MONITOR("Optimizer", Icons.Default.Memory),
    HISTORY("History & Stats", Icons.Default.Assessment),
    SHELL("Terminal", Icons.Default.Terminal)
}

enum class FilterType(val label: String) {
    ALL("All Apps"),
    USER("User Apps"),
    HIGH_RAM("High RAM (>150MB)"),
    SUSPENDED("Suspended")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun S21FERamManagerApp(
    isShizukuActive: Boolean,
    hasShizukuPermission: Boolean,
    onRequestPermission: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val historyRepo = remember { HistoryRepository.getInstance(context) }

    var currentTab by remember { mutableStateOf(NavigationTab.MONITOR) }
    var ramOverview by remember { mutableStateOf(RamOverview()) }
    var processList by remember { mutableStateOf<List<AppProcessInfo>>(emptyList()) }
    var suspendedPackages by remember { mutableStateOf<Set<String>>(emptySet()) }
    var isRefreshing by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf(FilterType.ALL) }
    var statusLog by remember { mutableStateOf<String?>(null) }
    var customCommand by remember { mutableStateOf("dumpsys meminfo") }
    var commandOutput by remember { mutableStateOf("") }

    var historyList by remember { mutableStateOf<List<CleaningHistoryRecord>>(emptyList()) }
    var statsSummary by remember { mutableStateOf(CleaningStatsSummary()) }
    var historyFilterAction by remember { mutableStateOf<CleaningAction?>(null) }
    var showClearConfirmDialog by remember { mutableStateOf(false) }

    fun refreshHistoryAndStats() {
        coroutineScope.launch {
            historyList = historyRepo.getAllHistory()
            statsSummary = historyRepo.getStatsSummary()
        }
    }

    fun refreshRamData() {
        coroutineScope.launch {
            isRefreshing = true
            val (overview, processes) = ShizukuCommandRunner.fetchMemoryInfo(context)
            ramOverview = overview
            processList = processes.map {
                it.copy(isSuspended = suspendedPackages.contains(it.packageName))
            }
            isRefreshing = false
        }
    }

    LaunchedEffect(isShizukuActive, hasShizukuPermission) {
        refreshHistoryAndStats()
        if (isShizukuActive && hasShizukuPermission) {
            refreshRamData()
        }
    }

    val filteredProcessList = remember(processList, searchQuery, selectedFilter, suspendedPackages) {
        processList.filter { app ->
            val matchesSearch = app.appName.contains(searchQuery, ignoreCase = true) ||
                    app.packageName.contains(searchQuery, ignoreCase = true)
            val matchesFilter = when (selectedFilter) {
                FilterType.ALL -> true
                FilterType.USER -> !app.isSystemApp
                FilterType.HIGH_RAM -> app.pssMb >= 150.0
                FilterType.SUSPENDED -> app.isSuspended
            }
            matchesSearch && matchesFilter
        }
    }

    val filteredHistory = remember(historyList, historyFilterAction) {
        if (historyFilterAction == null) historyList
        else historyList.filter { it.action == historyFilterAction }
    }

    if (showClearConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showClearConfirmDialog = false },
            title = { Text("Hapus semua riwayat?") },
            confirmButton = {
                TextButton(onClick = {
                    showClearConfirmDialog = false
                    coroutineScope.launch {
                        historyRepo.clearHistory()
                        refreshHistoryAndStats()
                    }
                }) { Text("Hapus") }
            },
            dismissButton = { TextButton(onClick = { showClearConfirmDialog = false }) { Text("Batal") } }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("S21FE RAM Manager", fontWeight = FontWeight.Bold, fontSize = 19.sp, color = Color.White)
                        Text("Galaxy S21 FE 5G • Shizuku Privileged Clean", fontSize = 11.sp, color = Color(0xFF94A3B8))
                    }
                },
                actions = {
                    if (currentTab == NavigationTab.MONITOR) {
                        IconButton(onClick = { refreshRamData() }) {
                            Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = Color(0xFF38BDF8))
                        }
                    } else if (currentTab == NavigationTab.HISTORY) {
                        IconButton(onClick = { showClearConfirmDialog = true }) {
                            Icon(Icons.Default.DeleteSweep, contentDescription = "Clear History", tint = Color(0xFFF87171))
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF0F172A))
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF0F172A), contentColor = Color.White) {
                NavigationTab.values().forEach { tab ->
                    NavigationBarItem(
                        selected = currentTab == tab,
                        onClick = {
                            currentTab = tab
                            if (tab == NavigationTab.HISTORY) refreshHistoryAndStats()
                        },
                        icon = { Icon(tab.icon, contentDescription = tab.title) },
                        label = { Text(tab.title, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = Color(0xFF38BDF8),
                            indicatorColor = Color(0xFF2563EB),
                            unselectedIconColor = Color(0xFF64748B),
                            unselectedTextColor = Color(0xFF64748B)
                        )
                    )
                }
            }
        },
        floatingActionButton = {
            if (currentTab == NavigationTab.MONITOR && isShizukuActive && hasShizukuPermission && processList.isNotEmpty()) {
                ExtendedFloatingActionButton(
                    onClick = {
                        coroutineScope.launch {
                            val targets = processList.filter { !it.isSystemApp && it.packageName != context.packageName }
                            var freedCount = 0
                            var freedMbTotal = 0.0

                            targets.forEach { target ->
                                val res = ShizukuCommandRunner.forceStopApp(target.packageName)
                                if (res.isSuccess) {
                                    freedCount++
                                    freedMbTotal += target.pssMb
                                    historyRepo.recordAction(
                                        packageName = target.packageName,
                                        appName = target.appName,
                                        action = CleaningAction.FORCE_STOP,
                                        estimatedRamFreedMb = target.pssMb
                                    )
                                }
                            }

                            if (freedCount > 0) {
                                historyRepo.recordAction(
                                    packageName = "batch.boost",
                                    appName = "Batch Deep Clean ($freedCount apps)",
                                    action = CleaningAction.BATCH_BOOST,
                                    estimatedRamFreedMb = freedMbTotal
                                )
                            }

                            Toast.makeText(context, "Freed ~${String.format("%.1f", freedMbTotal)} MB!", Toast.LENGTH_SHORT).show()
                            refreshRamData()
                            refreshHistoryAndStats()
                        }
                    },
                    containerColor = Color(0xFF2563EB),
                    contentColor = Color.White,
                    icon = { Icon(Icons.Default.Bolt, contentDescription = "Boost") },
                    text = { Text("Deep Clean (Boost)") }
                )
            }
        },
        containerColor = Color(0xFF090D16)
    ) { paddingValues ->
        Box(modifier = Modifier.fillMaxSize().padding(paddingValues)) {
            when (currentTab) {
                NavigationTab.MONITOR -> MonitorScreen(
                    isShizukuActive = isShizukuActive,
                    hasShizukuPermission = hasShizukuPermission,
                    onRequestPermission = onRequestPermission,
                    ramOverview = ramOverview,
                    isRefreshing = isRefreshing,
                    searchQuery = searchQuery,
                    onSearchChange = { searchQuery = it },
                    selectedFilter = selectedFilter,
                    onFilterChange = { selectedFilter = it },
                    filteredList = filteredProcessList,
                    onForceStop = { app ->
                        coroutineScope.launch {
                            val result = ShizukuCommandRunner.forceStopApp(app.packageName)
                            if (result.isSuccess) {
                                historyRepo.recordAction(
                                    packageName = app.packageName,
                                    appName = app.appName,
                                    action = CleaningAction.FORCE_STOP,
                                    estimatedRamFreedMb = app.pssMb
                                )
                                Toast.makeText(context, "Force stopped ${app.appName} (+${app.formattedRam} freed)", Toast.LENGTH_SHORT).show()
                                refreshRamData()
                                refreshHistoryAndStats()
                            }
                        }
                    },
                    onToggleSuspend = { app ->
                        coroutineScope.launch {
                            if (app.isSuspended) {
                                val res = ShizukuCommandRunner.unsuspendApp(app.packageName)
                                if (res.isSuccess) {
                                    suspendedPackages = suspendedPackages - app.packageName
                                    historyRepo.recordAction(
                                        packageName = app.packageName,
                                        appName = app.appName,
                                        action = CleaningAction.UNSUSPEND,
                                        estimatedRamFreedMb = 0.0
                                    )
                                    refreshRamData()
                                    refreshHistoryAndStats()
                                }
                            } else {
                                val res = ShizukuCommandRunner.suspendApp(app.packageName)
                                if (res.isSuccess) {
                                    suspendedPackages = suspendedPackages + app.packageName
                                    historyRepo.recordAction(
                                        packageName = app.packageName,
                                        appName = app.appName,
                                        action = CleaningAction.SUSPEND,
                                        estimatedRamFreedMb = app.pssMb * 0.75
                                    )
                                    refreshRamData()
                                    refreshHistoryAndStats()
                                }
                            }
                        }
                    }
                )
                NavigationTab.HISTORY -> HistoryAndStatsScreen(
                    statsSummary = statsSummary,
                    historyList = filteredHistory,
                    selectedActionFilter = historyFilterAction,
                    onActionFilterSelected = { historyFilterAction = it }
                )
                NavigationTab.SHELL -> ShellConsoleScreen(
                    isShizukuActive = isShizukuActive,
                    hasPermission = hasShizukuPermission,
                    command = customCommand,
                    onCommandChange = { customCommand = it },
                    output = commandOutput,
                    onExecute = { cmd ->
                        coroutineScope.launch {
                            commandOutput = "Running '$cmd' via Shizuku...\n"
                            val res = ShizukuCommandRunner.executeCommand(cmd)
                            commandOutput = res.getOrNull() ?: ("Error: " + res.exceptionOrNull()?.message)
                        }
                    }
                )
            }
        }
    }
}
