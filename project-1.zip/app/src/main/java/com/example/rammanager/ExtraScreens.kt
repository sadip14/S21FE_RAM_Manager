package com.example.rammanager

import android.Manifest
import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.view.Display
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.rammanager.battery.BatteryAnalyticsEngine
import com.example.rammanager.benchmark.DeviceBenchmarkEngine
import com.example.rammanager.benchmark.RealBenchmarkScores
import com.example.rammanager.data.BatteryHistoryRepository
import com.example.rammanager.model.*
import com.example.rammanager.service.BatteryMonitorForegroundService
import com.example.rammanager.shizuku.ShizukuCommandRunner
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
internal fun StatRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Muted, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Text(value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.End, modifier = Modifier.weight(1f))
    }
}

@Composable
internal fun Title(text: String) {
    Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    Spacer(Modifier.height(6.dp))
}

@Composable
internal fun Note(text: String) {
    Spacer(Modifier.height(6.dp))
    Text(text, color = Muted, fontSize = 11.sp)
}

@Composable
fun BatteryScreen() {
    val context = LocalContext.current
    val engine = remember { BatteryAnalyticsEngine(context) }
    val repo = remember { BatteryHistoryRepository.getInstance(context) }
    val prefs = remember { context.getSharedPreferences(BatteryMonitorForegroundService.PREFS, Context.MODE_PRIVATE) }
    val dateFmt = remember { SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()) }
    var percent by remember { mutableStateOf(0) }
    var flow by remember { mutableStateOf<BatteryCurrentFlow?>(null) }
    var est by remember { mutableStateOf<BatterySmartEstimates?>(null) }
    var health by remember { mutableStateOf<BatteryHealthReport?>(null) }
    var sessions by remember { mutableStateOf<List<BatterySessionRecord>>(emptyList()) }
    var learned by remember { mutableStateOf(false) }
    var serviceOn by remember { mutableStateOf(prefs.getBoolean(BatteryMonitorForegroundService.KEY_ENABLED, false)) }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(Unit) {
        while (true) {
            val f = engine.getLiveCurrentFlow(DESIGN_CAPACITY_MAH)
            val p = engine.readPercent()
            percent = p
            flow = f
            est = engine.calculateSmartEstimates(p, DESIGN_CAPACITY_MAH, f.isCharging, f.currentNowMa)
            val all = repo.getAllSessions()
            sessions = all
            learned = all.any { it.sessionType == BatterySessionType.DISCHARGING && it.durationMinutes >= 10 }
            health = repo.getHealthReport(DESIGN_CAPACITY_MAH, engine.instantCapacityMah(p))
            delay(3000)
        }
    }

    val f = flow
    val e = est
    val h = health
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (f != null) item {
            InfoCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("$percent%", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(if (f.isCharging) "Sedang mengisi" else "Tidak mengisi", color = Accent, fontWeight = FontWeight.SemiBold)
                        Text(f.chargeSpeedType, color = Muted, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(progress = { percent / 100f }, modifier = Modifier.fillMaxWidth(), color = Accent)
                Spacer(Modifier.height(8.dp))
                StatRow("Arus", if (f.currentAvailable) f.formattedCurrent else "Tidak tersedia di HP ini")
                StatRow("Daya", if (f.currentAvailable) f.formattedPower else "-")
                StatRow("Tegangan", "${f.voltageMv} mV")
                StatRow("Suhu", String.format("%.1f C", f.temperatureC))
            }
        }
        if (e != null && f != null) item {
            InfoCard {
                Title("Perkiraan Waktu")
                if (f.isCharging) {
                    StatRow("Penuh (100%)", e.formatMinutes(e.timeToFullMinutes))
                    StatRow("Mencapai 80%", if (percent >= 80) "Sudah" else e.formatMinutes(e.timeTo80PercentMinutes))
                } else {
                    StatRow("Layar menyala", e.formatMinutes(e.timeToEmptyScreenOnMinutes))
                    StatRow("Layar mati", e.formatMinutes(e.timeToEmptyScreenOffMinutes))
                    StatRow("Campuran", e.formatMinutes(e.timeToEmptyMixedMinutes))
                    Spacer(Modifier.height(6.dp))
                    e.activities.forEach { StatRow(it.activityName, it.formattedRemaining) }
                    Note("Per aktivitas = perkiraan umum, bukan hasil ukur HP kamu.")
                }
                if (!learned) Note("Estimasi awal. Makin akurat setelah ada riwayat pemakaian (aktifkan monitor latar belakang).")
            }
        }
        if (h != null) item {
            InfoCard {
                Title("Kesehatan Baterai")
                if (h.condition == "Belum cukup data") {
                    Text("Belum cukup data. Biarkan baterai di atas 20% lalu colok charger, atau aktifkan monitor latar belakang supaya sesi pengisian terekam.", color = Muted, fontSize = 12.sp)
                } else {
                    Text("${h.formattedHealth} - ${h.condition}", color = Accent, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    StatRow("Kapasitas terukur", h.formattedEstimatedCapacity)
                    StatRow("Kapasitas desain", "${h.designCapacityMah} mAh")
                    StatRow("Siklus terpantau", "${h.cycleCount}")
                    StatRow("Sesi isi dipelajari", "${h.totalSessionsLearned}")
                    StatRow("Keyakinan", "${h.accuracyScorePercent}%")
                    Note("Estimasi dari charge counter baterai. Akurasi tergantung HP dan membaik seiring data bertambah.")
                }
            }
        }
        item {
            InfoCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Monitor latar belakang", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text("Merekam sesi isi/pakai dan alarm di 80%. Tampil sebagai notifikasi tetap.", color = Muted, fontSize = 11.sp)
                    }
                    Switch(checked = serviceOn, onCheckedChange = { on ->
                        serviceOn = on
                        prefs.edit().putBoolean(BatteryMonitorForegroundService.KEY_ENABLED, on).apply()
                        if (on) {
                            if (Build.VERSION.SDK_INT >= 33 &&
                                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                            ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            BatteryMonitorForegroundService.startService(context)
                        } else {
                            BatteryMonitorForegroundService.stopService(context)
                        }
                    })
                }
            }
        }
        items(sessions.take(10)) { s ->
            InfoCard {
                Text("${s.sessionType.displayName}: ${s.startLevelPercent}% ke ${s.endLevelPercent}%", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                val energy = if (s.energyMah > 0.0) " | ${s.formattedEnergy}" else ""
                val avg = if (s.avgCurrentMa != 0) "${s.avgCurrentMa} mA" else "arus n/a"
                val peak = String.format("%.1f C", s.peakTemperatureC)
                Text("${s.durationMinutes} mnt$energy | $avg | $peak | ${dateFmt.format(Date(s.startTime))}", color = Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun BenchmarkScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var running by remember { mutableStateOf(false) }
    var phase by remember { mutableStateOf("") }
    var progress by remember { mutableStateOf(0) }
    var result by remember { mutableStateOf<RealBenchmarkScores?>(null) }
    val r = result
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            InfoCard {
                Title("Benchmark Ringan")
                Text("Tes CPU (integer & float), RAM, dan storage. Skor bersifat relatif, bukan skor AnTuTu, dan hasilnya terpengaruh suhu serta app yang berjalan.", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                Button(enabled = !running, onClick = {
                    running = true
                    result = null
                    scope.launch {
                        try {
                            result = DeviceBenchmarkEngine(context).runBenchmark { ph, pc -> phase = ph; progress = pc }
                        } catch (t: Throwable) {
                            phase = "Gagal: ${t.message}"
                        }
                        running = false
                    }
                }) { Text(if (running) "Berjalan..." else "Mulai Benchmark") }
                if (running) {
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth(), color = Accent)
                    Text(phase, color = Muted, fontSize = 12.sp)
                }
            }
        }
        if (r != null) item {
            InfoCard {
                Title("Skor Total: ${r.totalScore}")
                StatRow("CPU", "${r.cpuScore}")
                StatRow("Memori", "${r.memoryScore}")
                StatRow("Storage", "${r.storageScore}")
                StatRow("UX", "${r.uxScore}")
                Spacer(Modifier.height(6.dp))
                StatRow("Integer (sieve)", String.format("%.1f Mops/s", r.cpuSingleMops))
                StatRow("Float (matrix)", String.format("%.2f GFLOPS", r.cpuMultiGflops))
                StatRow("Bandwidth RAM", String.format("%.0f MB/s", r.ramBandwidthMbSec))
                StatRow("Storage", String.format("%.0f MB/s", r.storageSpeedMbSec))
                StatRow("Durasi", "${r.durationMs} ms")
            }
        }
    }
}

private fun readFile(path: String): String? = try { File(path).readText().trim() } catch (t: Throwable) { null }

private fun gb(bytes: Long) = String.format("%.1f GB", bytes / 1024.0 / 1024.0 / 1024.0)

@Composable
fun InfoScreen(shizukuReady: Boolean) {
    val context = LocalContext.current
    var gpu by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(shizukuReady) {
        if (shizukuReady) {
            val out = ShizukuCommandRunner.executeCommand("dumpsys SurfaceFlinger | grep GLES").getOrNull()
            gpu = out?.lineSequence()?.firstOrNull { it.contains("GLES") }?.trim()?.removePrefix("GLES:")?.trim() ?: "Tidak terbaca"
        }
    }
    val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
    val stat = StatFs(Environment.getDataDirectory().path)
    val dm = context.resources.displayMetrics
    val refresh = (context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY)?.refreshRate ?: 0f
    val cores = Runtime.getRuntime().availableProcessors()
    val maxFreqs = (0 until cores).mapNotNull { readFile("/sys/devices/system/cpu/cpu$it/cpufreq/cpuinfo_max_freq")?.toLongOrNull()?.let { k -> "${k / 1000}" } }
    val soc = if (Build.VERSION.SDK_INT >= 31) "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}" else Build.HARDWARE

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            InfoCard {
                Title("Perangkat")
                StatRow("Model", "${Build.MANUFACTURER} ${Build.MODEL}")
                StatRow("Android", "${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})")
                StatRow("Patch keamanan", Build.VERSION.SECURITY_PATCH)
                StatRow("Kernel", System.getProperty("os.version") ?: "-")
                StatRow("Build", Build.DISPLAY)
            }
        }
        item {
            InfoCard {
                Title("Prosesor & GPU")
                StatRow("SoC", soc)
                StatRow("Core", "$cores")
                StatRow("ABI", Build.SUPPORTED_ABIS.joinToString())
                StatRow("Clock maks (MHz)", if (maxFreqs.isEmpty()) "Dibatasi Android" else maxFreqs.joinToString(" / "))
                StatRow("GPU", gpu ?: if (shizukuReady) "Memuat..." else "Perlu Shizuku")
            }
        }
        item {
            InfoCard {
                Title("Layar, Memori & Storage")
                StatRow("Resolusi", "${dm.widthPixels} x ${dm.heightPixels} (${dm.densityDpi} dpi)")
                StatRow("Refresh rate", String.format("%.0f Hz", refresh))
                StatRow("RAM", "${gb(mi.availMem)} bebas / ${gb(mi.totalMem)}")
                StatRow("Storage", "${gb(stat.availableBlocksLong * stat.blockSizeLong)} bebas / ${gb(stat.blockCountLong * stat.blockSizeLong)}")
            }
        }
    }
}
