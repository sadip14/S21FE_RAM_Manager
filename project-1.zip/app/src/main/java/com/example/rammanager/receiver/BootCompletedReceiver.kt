package com.example.rammanager.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.rammanager.service.BatteryMonitorForegroundService

class BootCompletedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == "android.intent.action.QUICKBOOT_POWERON") {
            val prefs = context.getSharedPreferences("s21fe_battery_analytics_history", Context.MODE_PRIVATE)
            val isAutoStartEnabled = prefs.getBoolean("key_auto_start_background_service", false)
            if (isAutoStartEnabled) {
                BatteryMonitorForegroundService.startService(context)
            }
        }
    }
}
