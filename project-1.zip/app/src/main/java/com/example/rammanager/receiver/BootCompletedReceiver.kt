package com.example.rammanager.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.rammanager.service.BatteryMonitorForegroundService

/**
 * Receiver on phone boot.
 * Only starts the service if user explicitly enabled it previously (default disabled, Rule H.4).
 */
class BootCompletedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == "android.intent.action.QUICKBOOT_POWERON") {
            if (BatteryMonitorForegroundService.isServiceEnabled(context)) {
                BatteryMonitorForegroundService.startService(context)
            }
        }
    }
}
