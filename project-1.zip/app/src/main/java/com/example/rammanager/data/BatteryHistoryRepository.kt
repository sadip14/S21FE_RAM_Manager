package com.example.rammanager.data

import android.content.Context
import android.content.SharedPreferences
import com.example.rammanager.model.BatteryHealthReport
import com.example.rammanager.model.BatterySessionRecord
import com.example.rammanager.model.BatterySessionType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class BatteryHistoryRepository private constructor(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME = "s21fe_battery_analytics_history"
        private const val KEY_SESSIONS_DATA = "key_battery_sessions"
        private const val KEY_CYCLE_COUNT = "key_battery_cycle_count"
        private const val MAX_SESSIONS = 200

        @Volatile
        private var instance: BatteryHistoryRepository? = null

        fun getInstance(context: Context): BatteryHistoryRepository {
            return instance ?: synchronized(this) {
                instance ?: BatteryHistoryRepository(context).also { instance = it }
            }
        }
    }

    suspend fun recordSession(session: BatterySessionRecord): BatterySessionRecord = withContext(Dispatchers.IO) {
        val currentList = getAllSessionsInternal().toMutableList()
        currentList.add(0, session)
        if (currentList.size > MAX_SESSIONS) {
            currentList.subList(MAX_SESSIONS, currentList.size).clear()
        }
        saveSessionsInternal(currentList)

        if (session.sessionType == BatterySessionType.CHARGING && session.levelDelta > 10) {
            val deltaCycles = session.levelDelta / 100.0
            val existingCycles = prefs.getFloat(KEY_CYCLE_COUNT, 0f)
            prefs.edit().putFloat(KEY_CYCLE_COUNT, existingCycles + deltaCycles.toFloat()).apply()
        }
        session
    }

    suspend fun getAllSessions(): List<BatterySessionRecord> = withContext(Dispatchers.IO) {
        getAllSessionsInternal()
    }

    suspend fun clearSessions() = withContext(Dispatchers.IO) {
        prefs.edit().remove(KEY_SESSIONS_DATA).apply()
    }

    suspend fun getHealthReport(designCapacityMah: Int, instantCapacityMah: Double? = null): BatteryHealthReport = withContext(Dispatchers.IO) {
        val sessions = getAllSessionsInternal().filter {
            it.sessionType == BatterySessionType.CHARGING && it.levelDelta >= 15
        }
        val cycleCount = prefs.getFloat(KEY_CYCLE_COUNT, 0f).toInt()

        if (sessions.isEmpty()) {
            val inst = instantCapacityMah
            if (inst == null) {
                return@withContext BatteryHealthReport(designCapacityMah, 0.0, 0.0, cycleCount, 0.0, "Belum cukup data", 0, 0)
            }
            val cap = inst.coerceIn(designCapacityMah * 0.5, designCapacityMah * 1.05)
            val pct = cap / designCapacityMah * 100.0
            return@withContext BatteryHealthReport(designCapacityMah, cap, pct, cycleCount, (100.0 - pct).coerceAtLeast(0.0), conditionFor(pct), 0, 40)
        }

        var totalWeightedCapacity = 0.0
        var totalWeight = 0.0
        for (s in sessions) {
            val capacitySample = (s.energyMah / s.levelDelta.toDouble()) * 100.0
            val weight = s.levelDelta.toDouble()
            totalWeightedCapacity += (capacitySample * weight)
            totalWeight += weight
        }

        val estimatedCapacity = if (totalWeight > 0) totalWeightedCapacity / totalWeight else designCapacityMah.toDouble()
        val clampedCapacity = estimatedCapacity.coerceIn(designCapacityMah * 0.5, designCapacityMah * 1.05)
        val healthPercent = (clampedCapacity / designCapacityMah.toDouble()) * 100.0
        val wearLevel = (100.0 - healthPercent).coerceAtLeast(0.0)

        val condition = when {
            healthPercent >= 90.0 -> "Sangat Baik"
            healthPercent >= 80.0 -> "Baik"
            healthPercent >= 70.0 -> "Perlu Perhatian"
            else -> "Servis Baterai Disarankan"
        }

        val accuracyScore = (65 + (sessions.size * 5)).coerceAtMost(98)
        BatteryHealthReport(
            designCapacityMah = designCapacityMah,
            estimatedCapacityMah = clampedCapacity,
            healthPercent = healthPercent,
            cycleCount = cycleCount,
            wearLevelPercent = wearLevel,
            condition = condition,
            totalSessionsLearned = sessions.size,
            accuracyScorePercent = accuracyScore
        )
    }

    suspend fun getLearnedDrainRates(): Pair<Double, Double> = withContext(Dispatchers.IO) {
        val dischargeSessions = getAllSessionsInternal().filter {
            it.sessionType == BatterySessionType.DISCHARGING && it.durationMinutes >= 10
        }
        if (dischargeSessions.isEmpty()) {
            return@withContext Pair(14.5, 0.9)
        }
        var totalActiveRate = 0.0
        var count = 0
        for (s in dischargeSessions) {
            val ratePerHour = (s.levelDelta.toDouble() / s.durationMinutes.toDouble()) * 60.0
            totalActiveRate += ratePerHour
            count++
        }
        val avgActiveRate = if (count > 0) (totalActiveRate / count).coerceIn(8.0, 30.0) else 14.5
        Pair(avgActiveRate, (avgActiveRate * 0.06).coerceIn(0.5, 2.0))
    }

    private fun conditionFor(p: Double) = when {
        p >= 90.0 -> "Sangat Baik"
        p >= 80.0 -> "Baik"
        p >= 70.0 -> "Perlu Perhatian"
        else -> "Servis Baterai Disarankan"
    }

    suspend fun hasDischargeData(): Boolean = withContext(Dispatchers.IO) {
        getAllSessionsInternal().any { it.sessionType == BatterySessionType.DISCHARGING && it.durationMinutes >= 10 }
    }

    private fun getAllSessionsInternal(): List<BatterySessionRecord> {
        val jsonStr = prefs.getString(KEY_SESSIONS_DATA, null) ?: return emptyList()
        val list = mutableListOf<BatterySessionRecord>()
        try {
            val jsonArray = JSONArray(jsonStr)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                val typeName = obj.optString("sessionType", BatterySessionType.CHARGING.name)
                val sessionType = try {
                    BatterySessionType.valueOf(typeName)
                } catch (e: Exception) {
                    BatterySessionType.CHARGING
                }
                list.add(
                    BatterySessionRecord(
                        id = obj.optString("id", UUID.randomUUID().toString()),
                        sessionType = sessionType,
                        startTime = obj.optLong("startTime", System.currentTimeMillis() - 3600000),
                        endTime = obj.optLong("endTime", System.currentTimeMillis()),
                        durationMinutes = obj.optInt("durationMinutes", 45),
                        startLevelPercent = obj.optInt("startLevelPercent", 20),
                        endLevelPercent = obj.optInt("endLevelPercent", 80),
                        energyMah = obj.optDouble("energyMah", 2500.0),
                        avgCurrentMa = obj.optInt("avgCurrentMa", 2150),
                        peakTemperatureC = obj.optDouble("peakTemperatureC", 38.5),
                        chargerType = obj.optString("chargerType", "Fast 25W")
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    private fun saveSessionsInternal(list: List<BatterySessionRecord>) {
        try {
            val jsonArray = JSONArray()
            list.forEach { item ->
                val obj = JSONObject().apply {
                    put("id", item.id)
                    put("sessionType", item.sessionType.name)
                    put("startTime", item.startTime)
                    put("endTime", item.endTime)
                    put("durationMinutes", item.durationMinutes)
                    put("startLevelPercent", item.startLevelPercent)
                    put("endLevelPercent", item.endLevelPercent)
                    put("energyMah", item.energyMah)
                    put("avgCurrentMa", item.avgCurrentMa)
                    put("peakTemperatureC", item.peakTemperatureC)
                    put("chargerType", item.chargerType)
                }
                jsonArray.put(obj)
            }
            prefs.edit().putString(KEY_SESSIONS_DATA, jsonArray.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
