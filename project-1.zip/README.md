# Universal Device Monitor & System Optimizer (Shizuku + Jetpack Compose)

A lightweight, high-performance Android utility that works across all modern Android devices (Samsung, Xiaomi, Pixel, Oppo, Vivo, Motorola, Realme, etc.).

### Features
1. **Real-time Memory Inspection**: Queries real device RAM and PSS memory allocations per background process via Shizuku shell `dumpsys meminfo`.
2. **Force Stop Killer**: Terminates stubborn background battery and RAM hogs with privileged shell command `am force-stop <package_name>`.
3. **App Suspension**: Freezes non-essential apps without uninstalling using `pm suspend <package_name>` and `pm unsuspend <package_name>`.
4. **Native Battery Saver**: Toggles real Android battery saver mode via `settings put global low_power 1`.
5. **Thermal Sensor & Cool Down**: Monitors battery and SoC temperature via kernel thermal zones; cools down by immediately killing runaway CPU hogs.
6. **Hardware Specifications (DevCheck / AIDA64 style)**: Reads SoC chipset, CPU core frequencies, GPU renderer, display refresh rate (120Hz), kernel version, and internal storage.
7. **Whitelist Protection**: Protects essential apps (WhatsApp, Launcher, Music) from being touched by Deep Clean.
8. **Shizuku Privilege**: No root required! Works seamlessly via Wireless Debugging (port 5555/random pairing port).
9. **Automated GitHub Actions CI**: Compiles `app-debug.apk` automatically on push.

### How to Build APK
1. Open this folder in Android Studio (Giraffe / Hedgehog / Iguana / Koala / Ladybug or newer).
2. Connect device or start emulator.
3. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Or push this repository to GitHub; the `.github/workflows/build.yml` workflow will automatically output `app-debug.apk` in the Actions Artifacts tab!
